# SDC2 Final One-Click Environment

## What this package does

One batch file compiles/uploads the Arduino sketch with Arduino CLI, then starts the Python logger/menu.

The Arduino sketch includes:

- SWEEP mode and FULL mode
- 921600 baud serial logging to avoid blocking the motion loop at 100 Hz
- D12 external LED diagnostic output that toggles on every STEP pulse
- STOP command handling
- Watchdog messages when command steps are being issued but encoder count is not changing
- 24.65:1 gearbox conversion because the encoder is on the motor rear shaft before the gearbox
- 256 microstep debug setting

## Folder layout

Keep this structure:

```text
SDC2_Final_OneClick/
  upload_and_run_sdc2.bat
  sdc2_logger_plotter.py
  plot_existing_sdc2_csv.bat
  README.md
  SDC2_TestRunner_Menu/
    SDC2_TestRunner_Menu.ino
```

## Run

Double-click:

```text
upload_and_run_sdc2.bat
```

It will:

1. Compile `SDC2_TestRunner_Menu.ino`
2. Upload it to the Arduino GIGA on COM5
3. Start Python logger at 921600 baud
4. Ask you to select:
   - `1` = RPM/table-speed sweep
   - `2` = full SDC2 protocol run

## If your Arduino is not COM5

Edit `upload_and_run_sdc2.bat` and change:

```bat
set PORT=COM5
```

## LED wiring

Use an external LED on D12:

```text
D12 -> 220 or 330 ohm resistor -> LED anode/long leg
LED cathode/short leg -> GND
```

D12 toggles on every actual STEP pulse.

Do not use D13 for the LED because D13 is used as DIR.

## Emergency stop

The Python logger sends `STOP` if you press Ctrl+C, but the safest hard stop is still:

- press Arduino reset, or
- disable/power-cycle the R725.

Closing the terminal alone does not guarantee motor stop unless STOP is sent and received.

## Output

Results are saved in:

```text
SDC2_results/
  SDC2_SWEEP_raw_YYYYMMDD_HHMMSS.csv
  SDC2_clean.csv
  SDC2_trial_summary.csv
  split_trials_csv/
  figures/
```
