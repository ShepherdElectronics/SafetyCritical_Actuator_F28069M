@echo off
cd /d "%~dp0"

echo ============================================
echo SDC2 Test Runner
echo ============================================
echo.
echo Make sure SDC2_TestRunner_Menu.ino is uploaded first.
echo Make sure the Arduino COM port below is correct.
echo Current default: COM5
echo.
echo Select test mode:
echo   1. RPM / table-speed debug sweep
echo   2. Full SDC2 protocol run
echo.
set /p choice="Enter 1 or 2: "

if "%choice%"=="1" goto sweep
if "%choice%"=="2" goto full

echo Invalid selection.
pause
exit /b 1

:sweep
echo Running RPM/table-speed debug sweep...
python sdc2_logger_plotter.py --port COM5 --baud 115200 --mode SWEEP --outdir SDC2_results_SWEEP
goto done

:full
echo Running full SDC2 protocol...
python sdc2_logger_plotter.py --port COM5 --baud 115200 --mode FULL --outdir SDC2_results_FULL
goto done

:done
echo.
echo Finished. Check the output folder for CSVs and figures.
pause
