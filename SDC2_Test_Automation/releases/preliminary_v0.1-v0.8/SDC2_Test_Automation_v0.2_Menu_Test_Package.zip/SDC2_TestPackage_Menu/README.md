# SDC2 Menu Test Package

This package gives one Arduino sketch and one Windows command menu.

The menu lets you choose:

1. RPM / table-speed debug sweep
2. Full SDC2 protocol run

## Files

- `SDC2_TestRunner_Menu.ino` - Arduino sketch with both modes built in.
- `sdc2_logger_plotter.py` - Python serial logger, CSV splitter, summary generator, and plotter.
- `run_sdc2_menu.bat` - Windows menu for choosing sweep vs full run.
- `plot_existing_sdc2_csv.bat` - Re-plot an existing CSV.
- `README.md` - This file.

## Arduino pin map

- D10 = STEP output to R725 STEP
- D13 = DIR output to R725 DIR
- D2 = Encoder A from AM26LS32A
- D3 = Encoder B from AM26LS32A
- D4 = Encoder Z / Index from AM26LS32A, logged only
- D12 = external diagnostic LED

External LED wiring:

```text
Arduino D12 -> 220 or 330 ohm resistor -> LED long leg
LED short leg -> GND
```

D12 flickers whenever actual STEP pulses are generated.

## Gearbox / encoder math

The encoder is on the rear motor shaft before the gearbox.
The gearbox is treated as 24.65 motor revs per table rev.

```text
table angle = motor angle / 24.65
motor RPM = table speed [deg/s] * 24.65 / 6
```

## Before running

1. Put all files in one folder, for example:

```text
C:\Users\Jonathan\Documents\Phase2_testing
```

2. Open/upload `SDC2_TestRunner_Menu.ino` to the Arduino.

3. Make sure the COM port in `run_sdc2_menu.bat` is correct. It is currently set to COM5.

If your Arduino is not COM5, edit this line inside the BAT file:

```bat
--port COM5
```

## Run

Double-click:

```text
run_sdc2_menu.bat
```

Choose:

```text
1 = RPM/table-speed debug sweep
2 = Full protocol
```

The Python logger will send `SWEEP` or `FULL` to the Arduino automatically.

## Output folders

Sweep mode saves to:

```text
SDC2_results_SWEEP
```

Full mode saves to:

```text
SDC2_results_FULL
```

Each output folder contains:

```text
raw CSV
clean CSV
trial summary CSV
split_trials_csv/
figures/
comments txt
```

## Debug logic

If the motor does not move:

- D12 not flickering = Arduino is not sending STEP pulses.
- D12 flickering but encoder count does not change = R725/motor/power/wiring/enable issue, or motor not physically moving.
- D12 flickering and encoder count changes = command and feedback chain are alive.

Watchdog messages appear in the terminal and comments file if the Arduino is commanding steps but the encoder count does not change.
