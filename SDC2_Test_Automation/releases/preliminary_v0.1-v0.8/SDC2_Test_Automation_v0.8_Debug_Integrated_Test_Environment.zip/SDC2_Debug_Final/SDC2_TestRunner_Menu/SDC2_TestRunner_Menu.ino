/*
  SDC2 Test Runner Menu - Debug Final with SlowPlot and Diagnostics

  Hardware:
    Arduino GIGA R1 WiFi
    Lin Engineering R725 stepper driver
    Lin Engineering 4118M-06SD-I25-A0-A24F geared stepper
    US Digital E5 encoder on rear motor shaft, before gearbox
    AM26LS32A differential receiver

  Active pin map:
    D10 = STEP output to R725
    D13 = DIR output to R725
    D2  = Encoder A from AM26LS32A
    D3  = Encoder B from AM26LS32A
    D4  = Encoder Z/index from AM26LS32A, logged only
    D12 = external diagnostic LED, toggles on each STEP pulse

  Important:
    Encoder is on motor rear shaft before gearbox.
    Table/output angle = motor shaft angle / 24.65
*/

#define STEP_PIN 10
#define DIR_PIN 13
#define ENC_A 2
#define ENC_B 3
#define ENC_Z 4
#define MOTION_LED_PIN 12

const char* RUN_LABEL = "CENTERED_LOADFREE";
const char* FIRMWARE_VERSION = "SDC2_debug_vNext_diag_2026_05_31";

// Set true for fast iteration. Set false for final long characterization runs.
const bool FAST_DEBUG = true;

// Serial speed raised because 115200 baud can block Serial.print during 100 Hz CSV logging.
const unsigned long SERIAL_BAUD = 921600;

// Encoder / mechanical constants
const double CPR = 5000.0;
const double EDGE_MULT = 2.0;      // ENC_A CHANGE interrupt gives x2 decoding
const double GEAR_RATIO = 24.65;   // motor revs per table/output rev

const double ENCODER_COUNTS_PER_MOTOR_REV = CPR * EDGE_MULT;
const double ENCODER_COUNTS_PER_TABLE_REV = ENCODER_COUNTS_PER_MOTOR_REV * GEAR_RATIO;

// Driver constants
const double MOTOR_FULL_STEPS_PER_REV = 200.0;
const double MICROSTEP_SETTING = 256.0;   // Debug setting. Hardware DIP switches must match.
const double DRIVER_PULSES_PER_MOTOR_REV = MOTOR_FULL_STEPS_PER_REV * MICROSTEP_SETTING;
const double DRIVER_PULSES_PER_TABLE_REV = DRIVER_PULSES_PER_MOTOR_REV * GEAR_RATIO;
const double MOTOR_DEG_PER_STEP = 360.0 / DRIVER_PULSES_PER_MOTOR_REV;
const double TABLE_DEG_PER_STEP = 360.0 / DRIVER_PULSES_PER_TABLE_REV;

// Control constants
const double KP_POS = 0.35;
const double MAX_CORRECTION_STEP_RATE_HZ = 250.0;
const double CORRECTION_FRACTION_OF_BASE = 0.10;
const double MIN_CORRECTION_STEP_RATE_HZ = 2.0;
const unsigned long STEP_PULSE_HIGH_US = 5;
const double RAMP_TIME_SEC = FAST_DEBUG ? 0.5 : 1.0;

// Watchdog / diagnostics
const unsigned long WATCHDOG_INTERVAL_MS = 1000;
const unsigned long NO_ENCODER_TIMEOUT_MS = 3000;
const double MOTION_STEP_RATE_THRESHOLD_HZ = 0.10;

// Timing
const unsigned long START_DELAY_MS = FAST_DEBUG ? 1500UL : 3000UL;
const unsigned long BETWEEN_TEST_MS = FAST_DEBUG ? 500UL : 1500UL;
const unsigned long STATIC_50_MS = FAST_DEBUG ? 10000UL : 180000UL;
const unsigned long STATIC_100_MS = FAST_DEBUG ? 10000UL : 90000UL;
const unsigned long CONST_SPEED_MS = FAST_DEBUG ? 15000UL : 60000UL;

// Sweep mode
const unsigned long SWEEP_STATIC_MS = FAST_DEBUG ? 10000UL : 30000UL;
const unsigned long SWEEP_SPEED_MS = FAST_DEBUG ? 6000UL : 15000UL;
const int NUM_DEBUG_SPEEDS = 12;
const double DEBUG_SPEEDS_DEG_S[NUM_DEBUG_SPEEDS] = {
  0.01, 0.03, 0.1, 0.3, 1.0, 2.0,
  3.0, 5.0, 7.5, 10.0, 12.5, 15.0
};

// Slow encoder-plot validation mode.
// These speeds were chosen from encoder-count update rate limits at 256 microstepping.
// Positive direction only to keep total test time reasonable.
const unsigned long SLOWPLOT_STATIC_MS = FAST_DEBUG ? 10000UL : 30000UL;
const unsigned long SLOWPLOT_SPEED_MS = FAST_DEBUG ? 45000UL : 120000UL;  // debug: 45 s/speed; final: 2 min/speed
const int NUM_SLOWPLOT_SPEEDS = 6;
const double SLOWPLOT_SPEEDS_DEG_S[NUM_SLOWPLOT_SPEEDS] = {
  0.002, 0.003, 0.005, 0.010, 0.050, 0.100
};

// Open-loop STEP-frequency sweep mode.
// This bypasses encoder correction and simply sends fixed STEP rates to the R725.
// Use this to prove whether the driver/motor speeds up when STEP frequency increases.
const unsigned long OPENLOOP_STATIC_MS = FAST_DEBUG ? 5000UL : 10000UL;
const unsigned long OPENLOOP_STEP_TEST_MS = FAST_DEBUG ? 4000UL : 8000UL;
const int NUM_OPENLOOP_STEP_RATES = 9;
const double OPENLOOP_STEP_RATES_HZ[NUM_OPENLOOP_STEP_RATES] = {
  100.0, 300.0, 600.0, 1000.0, 3000.0,
  10000.0, 20000.0, 35000.0, 52500.0
};

// Open-loop RAMPED STEP-frequency sweep mode.
// This is safer/more diagnostic than jumping directly to 1000 Hz.
// It starts below the known-working ~35 Hz range and ramps into higher rates.
const unsigned long OPENRAMP_STATIC_MS = FAST_DEBUG ? 5000UL : 10000UL;
const unsigned long OPENRAMP_UP_MS = FAST_DEBUG ? 1500UL : 4000UL;
const unsigned long OPENRAMP_HOLD_MS = FAST_DEBUG ? 3000UL : 6000UL;
const unsigned long OPENRAMP_DOWN_MS = FAST_DEBUG ? 1500UL : 3000UL;
const int NUM_OPENRAMP_STEP_RATES = 14;
const double OPENRAMP_STEP_RATES_HZ[NUM_OPENRAMP_STEP_RATES] = {
  25.0, 35.0, 50.0, 75.0, 100.0, 150.0, 200.0,
  300.0, 500.0, 750.0, 1000.0, 1500.0, 3000.0, 5000.0
};

// Full protocol mode
const int NUM_SPEEDS = 7;
const double SPEEDS[NUM_SPEEDS] = {0.01, 0.03, 1.0, 3.0, 5.0, 10.0, 15.0};
const int NUM_SINE_PERIODS = 4;
const double SINE_PERIODS[NUM_SINE_PERIODS] = {3.0, 2.0, 1.0, 0.5};
const double SINE_PEAK_SPEED_DEG_S = 15.0;
const int SINE_CYCLES = 5;

// Encoder state
volatile long count = 0;

// Global timing
unsigned long runStart_us = 0;
unsigned long lastControl_us = 0;
unsigned long lastStep_us = 0;
unsigned long lastLog_us = 0;
unsigned long currentTestStart_us = 0;
unsigned long currentLogInterval_us = 10000UL;

// Control state
bool emergencyStopped = false;
bool motionLedState = false;
double commandTablePosition_deg = 0.0;
double commandTableSpeed_deg_s = 0.0;
double actualMotorPosition_deg = 0.0;
double actualTablePosition_deg = 0.0;
double tablePositionError_deg = 0.0;
double commandedStepRate_Hz = 0.0;
double feedforwardStepRate_Hz = 0.0;
double correctionStepRate_Hz = 0.0;

// Diagnostic state
const char* currentState = "BOOT";
const char* faultCode = "NONE";
unsigned long stepPulseCount = 0;
unsigned long loopDt_us = 0;
unsigned long maxLoopDt_us = 0;
unsigned long previousLoop_us = 0;
long zeroEncoderCount = 0;
bool pauseRequested = false;

// Encoder-derived moving-window speed estimate
unsigned long speedWindowStart_us = 0;
long speedWindowStartCount = 0;
double measuredSpeed_deg_s = 0.0;
double speedError_deg_s = 0.0;

// Test metadata
String selectedMode = "WAIT";
int testIndex = 0;
const char* currentTestName = "BOOT";
double currentTargetSpeed_deg_s = 0.0;
double currentMotorRPM = 0.0;
double currentSinePeriod_s = 0.0;

// Watchdog state
unsigned long lastWatchdog_ms = 0;
unsigned long lastEncoderMotion_ms = 0;
long lastWatchdogEncoderCount = 0;

void setup() {
  pinMode(STEP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(ENC_A, INPUT);
  pinMode(ENC_B, INPUT);
  pinMode(ENC_Z, INPUT);
  pinMode(MOTION_LED_PIN, OUTPUT);

  digitalWrite(STEP_PIN, LOW);
  digitalWrite(DIR_PIN, HIGH);
  digitalWrite(MOTION_LED_PIN, LOW);

  attachInterrupt(digitalPinToInterrupt(ENC_A), readEncoder, CHANGE);

  Serial.begin(SERIAL_BAUD);
  delay(1000);

  printBootInfo();
  waitForModeCommand();

  Serial.print("# MODE,");
  Serial.println(selectedMode);
  Serial.println("# Waiting before starting...");
  delay(START_DELAY_MS);

  runStart_us = micros();
  lastControl_us = runStart_us;
  lastStep_us = runStart_us;
  lastLog_us = runStart_us;
  lastWatchdog_ms = millis();
  lastEncoderMotion_ms = millis();
  lastWatchdogEncoderCount = getEncoderCount();
  zeroEncoderCount = lastWatchdogEncoderCount;
  speedWindowStart_us = runStart_us;
  speedWindowStartCount = lastWatchdogEncoderCount;
  previousLoop_us = runStart_us;

  printCsvHeader();

  if (selectedMode == "SWEEP") {
    runSweepTests();
  } else if (selectedMode == "FULL") {
    runFullTests();
  } else if (selectedMode == "OPENLOOP") {
    runOpenLoopStepFrequencyTests();
  } else if (selectedMode == "OPENRAMP") {
    runOpenLoopRampedStepFrequencyTests();
  } else if (selectedMode == "SLOWPLOT") {
    runSlowPlotTests();
  }

  emergencyStopMotion();
  Serial.println("# ALL_TESTS_COMPLETE");
}

void loop() {
  checkSerialStopCommand();
  emergencyStopMotion();
  delay(100);
}

void printBootInfo() {
  Serial.println("# SDC2 Test Runner Menu - Debug Final with SlowPlot and Diagnostics");
  Serial.print("# FIRMWARE_VERSION,"); Serial.println(FIRMWARE_VERSION);
  Serial.print("# FAST_DEBUG,"); Serial.println(FAST_DEBUG ? "true" : "false");
  Serial.println("# Send SWEEP for RPM/table-speed debug sweep");
  Serial.println("# Send FULL for full SDC2 protocol run");
  Serial.println("# Send OPENLOOP for fixed STEP-frequency sweep, no encoder correction");
  Serial.println("# Send OPENRAMP for ramped STEP-frequency sweep from 25 Hz upward");
  Serial.println("# Send SLOWPLOT for slow encoder-plot test: 0.002, 0.003, 0.005, 0.01, 0.05, 0.1 deg/s");
  Serial.println("# Send STOP anytime for emergency stop");
  Serial.print("# SERIAL_BAUD,"); Serial.println(SERIAL_BAUD);
  Serial.print("# RUN_LABEL,"); Serial.println(RUN_LABEL);
  Serial.print("# STEP_PIN,"); Serial.println(STEP_PIN);
  Serial.print("# DIR_PIN,"); Serial.println(DIR_PIN);
  Serial.print("# ENC_A,"); Serial.println(ENC_A);
  Serial.print("# ENC_B,"); Serial.println(ENC_B);
  Serial.print("# ENC_Z,"); Serial.println(ENC_Z);
  Serial.print("# MOTION_LED_PIN,"); Serial.println(MOTION_LED_PIN);
  Serial.print("# GEAR_RATIO,"); Serial.println(GEAR_RATIO, 5);
  Serial.print("# CPR,"); Serial.println(CPR, 0);
  Serial.print("# EDGE_MULT,"); Serial.println(EDGE_MULT, 0);
  Serial.print("# ENCODER_COUNTS_PER_MOTOR_REV,"); Serial.println(ENCODER_COUNTS_PER_MOTOR_REV, 3);
  Serial.print("# ENCODER_COUNTS_PER_TABLE_REV,"); Serial.println(ENCODER_COUNTS_PER_TABLE_REV, 3);
  Serial.print("# MICROSTEP_SETTING,"); Serial.println(MICROSTEP_SETTING, 0);
  Serial.print("# DRIVER_PULSES_PER_MOTOR_REV,"); Serial.println(DRIVER_PULSES_PER_MOTOR_REV, 0);
  Serial.print("# DRIVER_PULSES_PER_TABLE_REV,"); Serial.println(DRIVER_PULSES_PER_TABLE_REV, 3);
  Serial.print("# TABLE_DEG_PER_STEP,"); Serial.println(TABLE_DEG_PER_STEP, 9);
  Serial.print("# STEP_PULSE_HIGH_US,"); Serial.println(STEP_PULSE_HIGH_US);
  Serial.print("# KP_POS,"); Serial.println(KP_POS, 6);
  Serial.print("# MAX_CORRECTION_STEP_RATE_HZ,"); Serial.println(MAX_CORRECTION_STEP_RATE_HZ, 6);
  Serial.print("# CORRECTION_FRACTION_OF_BASE,"); Serial.println(CORRECTION_FRACTION_OF_BASE, 6);
  Serial.print("# MIN_CORRECTION_STEP_RATE_HZ,"); Serial.println(MIN_CORRECTION_STEP_RATE_HZ, 6);
  Serial.print("# SLOWPLOT_SPEED_MS,"); Serial.println(SLOWPLOT_SPEED_MS);
  Serial.print("# OPENRAMP_UP_MS,"); Serial.println(OPENRAMP_UP_MS);
  Serial.print("# OPENRAMP_HOLD_MS,"); Serial.println(OPENRAMP_HOLD_MS);
  Serial.print("# OPENRAMP_DOWN_MS,"); Serial.println(OPENRAMP_DOWN_MS);
  Serial.println("#");
}

void printCsvHeader() {
  Serial.println("RunLabel,Mode,TestIndex,TestName,State,Time_s,TestTime_s,SampleRate_Hz,TargetSpeed_deg_s,MotorRPM,SinePeriod_s,EncoderCount,ExpectedEncoderCount,EncoderCountError,CommandTablePosition_deg,ActualMotorPosition_deg,ActualTablePosition_deg,TablePositionError_deg,CommandTableSpeed_deg_s,CommandMotorSpeed_deg_s,FeedforwardStepRate_Hz,CorrectionStepRate_Hz,StepRate_Hz,StepPulseCount,MeasuredSpeed_deg_s,SpeedError_deg_s,LoopDt_us,MaxLoopDt_us,FaultCode,MotionActive,EncA,EncB,EncZ");
}

void waitForModeCommand() {
  unsigned long lastPrompt = 0;
  while (selectedMode == "WAIT") {
    if (millis() - lastPrompt > 1000) {
      Serial.println("# WAITING_FOR_MODE, send SWEEP, FULL, OPENLOOP, OPENRAMP, or SLOWPLOT");
      lastPrompt = millis();
    }
    if (Serial.available() > 0) {
      String cmd = Serial.readStringUntil('\n');
      cmd.trim();
      cmd.toUpperCase();
      if (cmd == "SWEEP" || cmd == "FULL" || cmd == "OPENLOOP" || cmd == "OPENRAMP" || cmd == "SLOWPLOT") {
        selectedMode = cmd;
        return;
      }
      if (cmd == "STOP") {
        emergencyStopMotion();
      }
    }
  }
}

void runSweepTests() {
  runTest("STATIC_50HZ_HOLD", 50.0, 0.0, SWEEP_STATIC_MS, 0.0);

  for (int i = 0; i < NUM_DEBUG_SPEEDS; i++) {
    runTest("DEBUG_SPEED_SWEEP_POS", 100.0, DEBUG_SPEEDS_DEG_S[i], SWEEP_SPEED_MS, 0.0);
  }

  for (int i = 0; i < NUM_DEBUG_SPEEDS; i++) {
    runTest("DEBUG_SPEED_SWEEP_NEG", 100.0, -DEBUG_SPEEDS_DEG_S[i], SWEEP_SPEED_MS, 0.0);
  }
}


void runSlowPlotTests() {
  // Static baseline first, then slow positive speed tests designed to produce visible encoder plots.
  runTest("SLOWPLOT_STATIC_50HZ_HOLD", 50.0, 0.0, SLOWPLOT_STATIC_MS, 0.0);

  for (int i = 0; i < NUM_SLOWPLOT_SPEEDS; i++) {
    runTest("SLOWPLOT_POS", 100.0, SLOWPLOT_SPEEDS_DEG_S[i], SLOWPLOT_SPEED_MS, 0.0);
  }
}


void runOpenLoopStepFrequencyTests() {
  // First log stationary data for a short baseline.
  runOpenLoopStepRateTest("OPENLOOP_STATIC", 50.0, 0.0, OPENLOOP_STATIC_MS);

  // Positive fixed STEP-frequency sweep.
  for (int i = 0; i < NUM_OPENLOOP_STEP_RATES; i++) {
    runOpenLoopStepRateTest("OPENLOOP_STEP_HZ_POS", 100.0, OPENLOOP_STEP_RATES_HZ[i], OPENLOOP_STEP_TEST_MS);
  }

  // Negative fixed STEP-frequency sweep.
  for (int i = 0; i < NUM_OPENLOOP_STEP_RATES; i++) {
    runOpenLoopStepRateTest("OPENLOOP_STEP_HZ_NEG", 100.0, -OPENLOOP_STEP_RATES_HZ[i], OPENLOOP_STEP_TEST_MS);
  }
}


void runOpenLoopRampedStepFrequencyTests() {
  // First log stationary data for a short baseline.
  runOpenLoopStepRateTest("OPENRAMP_STATIC", 50.0, 0.0, OPENRAMP_STATIC_MS);

  // Positive ramped STEP-frequency sweep.
  for (int i = 0; i < NUM_OPENRAMP_STEP_RATES; i++) {
    runOpenLoopRampedStepRateTest("OPENRAMP_STEP_HZ_POS", 100.0, OPENRAMP_STEP_RATES_HZ[i],
                                  OPENRAMP_UP_MS, OPENRAMP_HOLD_MS, OPENRAMP_DOWN_MS);
  }

  // Negative ramped STEP-frequency sweep.
  for (int i = 0; i < NUM_OPENRAMP_STEP_RATES; i++) {
    runOpenLoopRampedStepRateTest("OPENRAMP_STEP_HZ_NEG", 100.0, -OPENRAMP_STEP_RATES_HZ[i],
                                  OPENRAMP_UP_MS, OPENRAMP_HOLD_MS, OPENRAMP_DOWN_MS);
  }
}

void runFullTests() {
  runTest("STATIC_50HZ_HOLD", 50.0, 0.0, STATIC_50_MS, 0.0);
  runTest("STATIC_100HZ_HOLD", 100.0, 0.0, STATIC_100_MS, 0.0);

  for (int i = 0; i < NUM_SPEEDS; i++) runTest("CONST_POS_ASC", 100.0, SPEEDS[i], CONST_SPEED_MS, 0.0);
  for (int i = NUM_SPEEDS - 1; i >= 0; i--) runTest("CONST_POS_DESC", 100.0, SPEEDS[i], CONST_SPEED_MS, 0.0);
  for (int i = 0; i < NUM_SPEEDS; i++) runTest("CONST_NEG_ASC", 100.0, -SPEEDS[i], CONST_SPEED_MS, 0.0);
  for (int i = NUM_SPEEDS - 1; i >= 0; i--) runTest("CONST_NEG_DESC", 100.0, -SPEEDS[i], CONST_SPEED_MS, 0.0);

  for (int i = 0; i < NUM_SINE_PERIODS; i++) {
    unsigned long duration_ms = (unsigned long)(SINE_CYCLES * SINE_PERIODS[i] * 1000.0);
    runTest("SINE_VEL", 100.0, 0.0, duration_ms, SINE_PERIODS[i]);
  }
}


void runOpenLoopRampedStepRateTest(const char* name, double sampleRate_Hz, double targetStepRate_Hz,
                                   unsigned long rampUp_ms, unsigned long hold_ms, unsigned long rampDown_ms) {
  testIndex++;
  currentTestName = name;
  currentState = "START_TEST";
  faultCode = "NONE";
  maxLoopDt_us = 0;
  currentTargetSpeed_deg_s = targetStepRate_Hz * TABLE_DEG_PER_STEP;
  currentMotorRPM = abs(currentTargetSpeed_deg_s) * GEAR_RATIO / 6.0;
  currentSinePeriod_s = 0.0;
  currentLogInterval_us = (unsigned long)(1000000.0 / sampleRate_Hz);
  currentTestStart_us = micros();
  lastControl_us = currentTestStart_us;
  lastLog_us = currentTestStart_us;

  unsigned long duration_ms = rampUp_ms + hold_ms + rampDown_ms;

  Serial.print("# START_TEST,");
  Serial.print(selectedMode); Serial.print(",");
  Serial.print(testIndex); Serial.print(",");
  Serial.print(currentTestName); Serial.print(",TargetStepRate_Hz,");
  Serial.print(targetStepRate_Hz, 6); Serial.print(",EquivalentTableSpeed_deg_s,");
  Serial.print(currentTargetSpeed_deg_s, 9); Serial.print(",MotorRPM,");
  Serial.print(currentMotorRPM, 6); Serial.print(",RampUp_ms,");
  Serial.print(rampUp_ms); Serial.print(",Hold_ms,");
  Serial.print(hold_ms); Serial.print(",RampDown_ms,");
  Serial.print(rampDown_ms); Serial.print(",SampleRate,");
  Serial.println(sampleRate_Hz, 3);

  while ((millisSince_us(currentTestStart_us)) < duration_ms) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    if (pauseRequested) { emergencyStopMotionSoft(); delay(10); continue; }

    unsigned long now_us = micros();
    updateLoopDiagnostics(now_us);
    unsigned long elapsed_ms = millisSince_us(currentTestStart_us);
    double scale = 0.0;

    if (elapsed_ms < rampUp_ms) {
      currentState = "RAMP_UP";
      scale = (double)elapsed_ms / (double)rampUp_ms;
    } else if (elapsed_ms < (rampUp_ms + hold_ms)) {
      currentState = "HOLD_SPEED";
      scale = 1.0;
    } else {
      currentState = "RAMP_DOWN";
      unsigned long downElapsed_ms = elapsed_ms - rampUp_ms - hold_ms;
      scale = 1.0 - ((double)downElapsed_ms / (double)rampDown_ms);
      if (scale < 0.0) scale = 0.0;
    }

    double instantaneousStepRate_Hz = targetStepRate_Hz * scale;
    updateOpenLoopState(now_us, instantaneousStepRate_Hz);
    generateStepIfNeeded(now_us);
    updateMotionDiagnostics();
    logData(now_us, sampleRate_Hz);
  }

  emergencyStopMotionSoft();
  unsigned long stopStart_us = micros();
  while (millisSince_us(stopStart_us) < BETWEEN_TEST_MS) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    emergencyStopMotionSoft();
  }

  Serial.print("# END_TEST,");
  Serial.print(testIndex); Serial.print(",");
  Serial.println(currentTestName);
}

void runOpenLoopStepRateTest(const char* name, double sampleRate_Hz, double fixedStepRate_Hz, unsigned long duration_ms) {
  testIndex++;
  currentTestName = name;
  currentState = "START_TEST";
  faultCode = "NONE";
  maxLoopDt_us = 0;
  currentTargetSpeed_deg_s = fixedStepRate_Hz * TABLE_DEG_PER_STEP;
  currentMotorRPM = abs(currentTargetSpeed_deg_s) * GEAR_RATIO / 6.0;
  currentSinePeriod_s = 0.0;
  currentLogInterval_us = (unsigned long)(1000000.0 / sampleRate_Hz);
  currentTestStart_us = micros();
  lastControl_us = currentTestStart_us;
  lastLog_us = currentTestStart_us;

  Serial.print("# START_TEST,");
  Serial.print(selectedMode); Serial.print(",");
  Serial.print(testIndex); Serial.print(",");
  Serial.print(currentTestName); Serial.print(",FixedStepRate_Hz,");
  Serial.print(fixedStepRate_Hz, 6); Serial.print(",EquivalentTableSpeed_deg_s,");
  Serial.print(currentTargetSpeed_deg_s, 9); Serial.print(",MotorRPM,");
  Serial.print(currentMotorRPM, 6); Serial.print(",SampleRate,");
  Serial.println(sampleRate_Hz, 3);

  while ((millisSince_us(currentTestStart_us)) < duration_ms) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    if (pauseRequested) { emergencyStopMotionSoft(); delay(10); continue; }

    unsigned long now_us = micros();
    updateLoopDiagnostics(now_us);
    currentState = (abs(fixedStepRate_Hz) < 0.001) ? "HOLD_STATIC" : "HOLD_SPEED";
    updateOpenLoopState(now_us, fixedStepRate_Hz);
    generateStepIfNeeded(now_us);
    updateMotionDiagnostics();
    logData(now_us, sampleRate_Hz);
  }

  emergencyStopMotionSoft();
  unsigned long stopStart_us = micros();
  while (millisSince_us(stopStart_us) < BETWEEN_TEST_MS) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    emergencyStopMotionSoft();
  }

  Serial.print("# END_TEST,");
  Serial.print(testIndex); Serial.print(",");
  Serial.println(currentTestName);
}

void runTest(const char* name, double sampleRate_Hz, double targetSpeed_deg_s, unsigned long duration_ms, double sinePeriod_s) {
  testIndex++;
  currentTestName = name;
  currentState = "START_TEST";
  faultCode = "NONE";
  maxLoopDt_us = 0;
  currentTargetSpeed_deg_s = targetSpeed_deg_s;
  currentMotorRPM = abs(targetSpeed_deg_s) * GEAR_RATIO / 6.0;
  currentSinePeriod_s = sinePeriod_s;
  currentLogInterval_us = (unsigned long)(1000000.0 / sampleRate_Hz);
  currentTestStart_us = micros();
  lastControl_us = currentTestStart_us;
  lastLog_us = currentTestStart_us;

  Serial.print("# START_TEST,");
  Serial.print(selectedMode); Serial.print(",");
  Serial.print(testIndex); Serial.print(",");
  Serial.print(currentTestName); Serial.print(",TargetSpeed,");
  Serial.print(currentTargetSpeed_deg_s, 6); Serial.print(",MotorRPM,");
  Serial.print(currentMotorRPM, 6); Serial.print(",SinePeriod,");
  Serial.print(currentSinePeriod_s, 6); Serial.print(",SampleRate,");
  Serial.println(sampleRate_Hz, 3);

  while ((millisSince_us(currentTestStart_us)) < duration_ms) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    if (pauseRequested) { emergencyStopMotionSoft(); delay(10); continue; }

    unsigned long now_us = micros();
    updateLoopDiagnostics(now_us);
    updateCommandForCurrentTest(now_us);
    updateClosedLoop(now_us);
    generateStepIfNeeded(now_us);
    updateMotionDiagnostics();
    logData(now_us, sampleRate_Hz);
  }

  emergencyStopMotionSoft();
  unsigned long stopStart_us = micros();
  while (millisSince_us(stopStart_us) < BETWEEN_TEST_MS) {
    checkSerialStopCommand();
    if (emergencyStopped) return;
    unsigned long now_us = micros();
    commandTableSpeed_deg_s = 0.0;
    updateClosedLoop(now_us);
    generateStepIfNeeded(now_us);
    updateMotionDiagnostics();
  }

  Serial.print("# END_TEST,");
  Serial.print(testIndex); Serial.print(",");
  Serial.println(currentTestName);
}

unsigned long millisSince_us(unsigned long start_us) {
  return (micros() - start_us) / 1000UL;
}

void updateCommandForCurrentTest(unsigned long now_us) {
  double testTime_s = (now_us - currentTestStart_us) / 1000000.0;
  if (currentSinePeriod_s > 0.0) {
    currentState = "SINE_SCAN";
    double omega = 2.0 * PI / currentSinePeriod_s;
    commandTableSpeed_deg_s = SINE_PEAK_SPEED_DEG_S * sin(omega * testTime_s);
  } else {
    double rampScale = 1.0;
    if (abs(currentTargetSpeed_deg_s) < 1e-12) {
      currentState = "HOLD_STATIC";
    } else if (testTime_s < RAMP_TIME_SEC) {
      currentState = "RAMP_UP";
      rampScale = testTime_s / RAMP_TIME_SEC;
    } else {
      currentState = "HOLD_SPEED";
    }
    commandTableSpeed_deg_s = currentTargetSpeed_deg_s * rampScale;
  }
}


void updateOpenLoopState(unsigned long now_us, double fixedStepRate_Hz) {
  double dt_s = (now_us - lastControl_us) / 1000000.0;
  if (dt_s <= 0.0) return;
  lastControl_us = now_us;

  feedforwardStepRate_Hz = fixedStepRate_Hz;
  correctionStepRate_Hz = 0.0;
  commandedStepRate_Hz = fixedStepRate_Hz;
  commandTableSpeed_deg_s = fixedStepRate_Hz * TABLE_DEG_PER_STEP;
  commandTablePosition_deg += commandTableSpeed_deg_s * dt_s;

  long currentCount = getEncoderCount();
  actualMotorPosition_deg = encoderCountToMotorDeg(currentCount);
  actualTablePosition_deg = actualMotorPosition_deg / GEAR_RATIO;
  tablePositionError_deg = commandTablePosition_deg - actualTablePosition_deg;
}

void updateClosedLoop(unsigned long now_us) {
  double dt_s = (now_us - lastControl_us) / 1000000.0;
  if (dt_s <= 0.0) return;
  lastControl_us = now_us;

  commandTablePosition_deg += commandTableSpeed_deg_s * dt_s;

  long currentCount = getEncoderCount();
  actualMotorPosition_deg = encoderCountToMotorDeg(currentCount);
  actualTablePosition_deg = actualMotorPosition_deg / GEAR_RATIO;
  tablePositionError_deg = commandTablePosition_deg - actualTablePosition_deg;

  feedforwardStepRate_Hz = commandTableSpeed_deg_s / TABLE_DEG_PER_STEP;
  correctionStepRate_Hz = (KP_POS * tablePositionError_deg) / TABLE_DEG_PER_STEP;

  // Low-bandwidth background trim: cap correction as a small fraction of feedforward.
  double dynamicCorrectionCap_Hz = max(MIN_CORRECTION_STEP_RATE_HZ, CORRECTION_FRACTION_OF_BASE * abs(feedforwardStepRate_Hz));
  if (dynamicCorrectionCap_Hz > MAX_CORRECTION_STEP_RATE_HZ) dynamicCorrectionCap_Hz = MAX_CORRECTION_STEP_RATE_HZ;

  if (correctionStepRate_Hz > dynamicCorrectionCap_Hz) correctionStepRate_Hz = dynamicCorrectionCap_Hz;
  if (correctionStepRate_Hz < -dynamicCorrectionCap_Hz) correctionStepRate_Hz = -dynamicCorrectionCap_Hz;

  commandedStepRate_Hz = feedforwardStepRate_Hz + correctionStepRate_Hz;
}

void generateStepIfNeeded(unsigned long now_us) {
  if (emergencyStopped) return;
  if (commandedStepRate_Hz == 0.0) return;

  bool forward = commandedStepRate_Hz > 0.0;
  double absStepRate_Hz = abs(commandedStepRate_Hz);
  if (absStepRate_Hz < 0.001) return;

  unsigned long stepInterval_us = (unsigned long)(1000000.0 / absStepRate_Hz);
  if (stepInterval_us < (STEP_PULSE_HIGH_US + 2)) {
    stepInterval_us = STEP_PULSE_HIGH_US + 2;
  }

  if (now_us - lastStep_us >= stepInterval_us) {
    digitalWrite(DIR_PIN, forward ? HIGH : LOW);

    motionLedState = !motionLedState;
    digitalWrite(MOTION_LED_PIN, motionLedState ? HIGH : LOW);

    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(STEP_PULSE_HIGH_US);
    digitalWrite(STEP_PIN, LOW);

    lastStep_us = micros();
    stepPulseCount++;
  }
}

void updateMotionDiagnostics() {
  unsigned long now_ms = millis();
  long currentCount = getEncoderCount();
  bool commandActive = abs(commandedStepRate_Hz) > MOTION_STEP_RATE_THRESHOLD_HZ;
  bool encoderChanged = (currentCount != lastWatchdogEncoderCount);

  if (encoderChanged) {
    lastEncoderMotion_ms = now_ms;
    lastWatchdogEncoderCount = currentCount;
  }

  if (now_ms - lastWatchdog_ms >= WATCHDOG_INTERVAL_MS) {
    lastWatchdog_ms = now_ms;
    if (commandActive && !encoderChanged) {
      faultCode = "WARN_NO_ENCODER_CHANGE";
      Serial.print("# WATCHDOG,COMMANDING_STEPS_NO_ENCODER_CHANGE,Time_ms,");
      Serial.print(now_ms);
      Serial.print(",StepRate_Hz,");
      Serial.print(commandedStepRate_Hz, 6);
      Serial.print(",EncoderCount,");
      Serial.println(currentCount);
    }
    if (commandActive && (now_ms - lastEncoderMotion_ms > NO_ENCODER_TIMEOUT_MS)) {
      faultCode = "FAULT_NO_ENCODER_MOTION";
      Serial.print("# FAULT,NO_ENCODER_MOTION_FOR_");
      Serial.print(NO_ENCODER_TIMEOUT_MS);
      Serial.print("_MS,StepRate_Hz,");
      Serial.print(commandedStepRate_Hz, 6);
      Serial.print(",EncoderCount,");
      Serial.println(currentCount);
    }
  }
}

void updateSpeedEstimate(unsigned long now_us, long currentCount) {
  if (speedWindowStart_us == 0) {
    speedWindowStart_us = now_us;
    speedWindowStartCount = currentCount;
    return;
  }

  unsigned long window_us = now_us - speedWindowStart_us;
  if (window_us >= 500000UL) {  // 0.5 s moving estimate window
    long deltaCounts = currentCount - speedWindowStartCount;
    double dt_s = window_us / 1000000.0;
    double deltaMotor_deg = encoderCountToMotorDeg(deltaCounts);
    double deltaTable_deg = deltaMotor_deg / GEAR_RATIO;
    measuredSpeed_deg_s = deltaTable_deg / dt_s;
    speedError_deg_s = measuredSpeed_deg_s - commandTableSpeed_deg_s;
    speedWindowStart_us = now_us;
    speedWindowStartCount = currentCount;
  }
}

long expectedEncoderCountFromCommand() {
  double countsFromCommand = (commandTablePosition_deg / 360.0) * ENCODER_COUNTS_PER_TABLE_REV;
  return zeroEncoderCount + (long)round(countsFromCommand);
}

void updateLoopDiagnostics(unsigned long now_us) {
  if (previousLoop_us > 0) {
    loopDt_us = now_us - previousLoop_us;
    if (loopDt_us > maxLoopDt_us) maxLoopDt_us = loopDt_us;
    if (loopDt_us > 50000UL) {
      faultCode = "WARN_LOOP_OVERRUN";
    }
  }
  previousLoop_us = now_us;
}

void logData(unsigned long now_us, double sampleRate_Hz) {
  if (now_us - lastLog_us < currentLogInterval_us) return;

  long currentCount = getEncoderCount();
  updateSpeedEstimate(now_us, currentCount);

  double motor_deg = encoderCountToMotorDeg(currentCount);
  double table_deg = motor_deg / GEAR_RATIO;
  double table_error_deg = commandTablePosition_deg - table_deg;
  double command_motor_speed_deg_s = commandTableSpeed_deg_s * GEAR_RATIO;
  double runTime_s = (now_us - runStart_us) / 1000000.0;
  double testTime_s = (now_us - currentTestStart_us) / 1000000.0;
  long expectedCount = expectedEncoderCountFromCommand();
  long encoderCountError = expectedCount - currentCount;
  bool motionActive = abs(commandedStepRate_Hz) > MOTION_STEP_RATE_THRESHOLD_HZ;

  Serial.print(RUN_LABEL); Serial.print(",");
  Serial.print(selectedMode); Serial.print(",");
  Serial.print(testIndex); Serial.print(",");
  Serial.print(currentTestName); Serial.print(",");
  Serial.print(currentState); Serial.print(",");
  Serial.print(runTime_s, 6); Serial.print(",");
  Serial.print(testTime_s, 6); Serial.print(",");
  Serial.print(sampleRate_Hz, 3); Serial.print(",");
  Serial.print(currentTargetSpeed_deg_s, 6); Serial.print(",");
  Serial.print(currentMotorRPM, 6); Serial.print(",");
  Serial.print(currentSinePeriod_s, 6); Serial.print(",");
  Serial.print(currentCount); Serial.print(",");
  Serial.print(expectedCount); Serial.print(",");
  Serial.print(encoderCountError); Serial.print(",");
  Serial.print(commandTablePosition_deg, 6); Serial.print(",");
  Serial.print(motor_deg, 6); Serial.print(",");
  Serial.print(table_deg, 6); Serial.print(",");
  Serial.print(table_error_deg, 6); Serial.print(",");
  Serial.print(commandTableSpeed_deg_s, 6); Serial.print(",");
  Serial.print(command_motor_speed_deg_s, 6); Serial.print(",");
  Serial.print(feedforwardStepRate_Hz, 6); Serial.print(",");
  Serial.print(correctionStepRate_Hz, 6); Serial.print(",");
  Serial.print(commandedStepRate_Hz, 6); Serial.print(",");
  Serial.print(stepPulseCount); Serial.print(",");
  Serial.print(measuredSpeed_deg_s, 9); Serial.print(",");
  Serial.print(speedError_deg_s, 9); Serial.print(",");
  Serial.print(loopDt_us); Serial.print(",");
  Serial.print(maxLoopDt_us); Serial.print(",");
  Serial.print(faultCode); Serial.print(",");
  Serial.print(motionActive ? 1 : 0); Serial.print(",");
  Serial.print(digitalRead(ENC_A)); Serial.print(",");
  Serial.print(digitalRead(ENC_B)); Serial.print(",");
  Serial.println(digitalRead(ENC_Z));

  lastLog_us += currentLogInterval_us;
}

void checkSerialStopCommand() {
  while (Serial.available() > 0) {
    String rawCmd = Serial.readStringUntil('\n');
    rawCmd.trim();
    String upper = rawCmd;
    upper.toUpperCase();

    if (upper == "STOP") {
      emergencyStopped = true;
      currentState = "STOPPED";
      faultCode = "STOP_COMMAND";
      emergencyStopMotion();
      Serial.println("# EMERGENCY_STOP_RECEIVED");
    } else if (upper == "PAUSE") {
      pauseRequested = true;
      currentState = "PAUSED";
      emergencyStopMotionSoft();
      Serial.println("# PAUSE_RECEIVED");
    } else if (upper == "RESUME") {
      pauseRequested = false;
      currentState = "RESUME";
      Serial.println("# RESUME_RECEIVED");
    } else if (upper == "ZERO") {
      noInterrupts();
      count = 0;
      interrupts();
      zeroEncoderCount = 0;
      commandTablePosition_deg = 0.0;
      speedWindowStart_us = micros();
      speedWindowStartCount = 0;
      Serial.println("# ZERO_RECEIVED,ENCODER_AND_COMMAND_ZEROED");
    } else if (upper == "STATUS") {
      Serial.print("# STATUS,State,"); Serial.print(currentState);
      Serial.print(",FaultCode,"); Serial.print(faultCode);
      Serial.print(",EncoderCount,"); Serial.print(getEncoderCount());
      Serial.print(",CommandTableSpeed_deg_s,"); Serial.print(commandTableSpeed_deg_s, 9);
      Serial.print(",StepRate_Hz,"); Serial.print(commandedStepRate_Hz, 6);
      Serial.print(",StepPulseCount,"); Serial.println(stepPulseCount);
    } else if (upper.startsWith("MARK")) {
      Serial.print("# MARK,");
      Serial.print((micros() - runStart_us) / 1000000.0, 6);
      Serial.print(",");
      Serial.println(rawCmd);
    }
  }
}

void emergencyStopMotionSoft() {
  commandTableSpeed_deg_s = 0.0;
  feedforwardStepRate_Hz = 0.0;
  correctionStepRate_Hz = 0.0;
  commandedStepRate_Hz = 0.0;
  digitalWrite(STEP_PIN, LOW);
  digitalWrite(MOTION_LED_PIN, LOW);
}

void emergencyStopMotion() {
  commandTableSpeed_deg_s = 0.0;
  feedforwardStepRate_Hz = 0.0;
  correctionStepRate_Hz = 0.0;
  commandedStepRate_Hz = 0.0;
  digitalWrite(STEP_PIN, LOW);
  digitalWrite(MOTION_LED_PIN, LOW);
}

void readEncoder() {
  if (digitalRead(ENC_A) == digitalRead(ENC_B)) {
    count--;
  } else {
    count++;
  }
}

long getEncoderCount() {
  noInterrupts();
  long c = count;
  interrupts();
  return c;
}

double encoderCountToMotorDeg(long encoderCount) {
  return (encoderCount * 360.0) / ENCODER_COUNTS_PER_MOTOR_REV;
}
