# SDC2 Final One-Click Environment

## What this package does

One batch file compiles/uploads the Arduino sketch with Arduino CLI, then starts the Python logger/menu.

The Arduino sketch includes:

- SWEEP mode, FULL mode, and OPENLOOP fixed STEP-frequency sweep mode
- 921600 baud serial logging to avoid blocking the motion loop at 100 Hz
- D12 external LED diagnostic output that toggles on every STEP pulse
- STOP command handling
- Watchdog messages when command steps are being issued but encoder count is not changing
- 24.65:1 gearbox conversion because the encoder is on the motor rear shaft before the gearbox
- 256 microstep debug setting

## Folder layout

Keep this structure:

```text
SDC2_Final_OneClick/
  upload_and_run_sdc2.bat
  sdc2_logger_plotter.py
  plot_existing_sdc2_csv.bat
  README.md
  SDC2_TestRunner_Menu/
    SDC2_TestRunner_Menu.ino
```

## Run

Double-click:

```text
upload_and_run_sdc2.bat
```

It will:

1. Compile `SDC2_TestRunner_Menu.ino`
2. Upload it to the Arduino GIGA on COM5
3. Start Python logger at 921600 baud
4. Ask you to select:
   - `1` = RPM/table-speed sweep
   - `2` = full SDC2 protocol run
   - `3` = open-loop fixed STEP-frequency sweep

## Open-loop STEP-frequency sweep

Use option `3` if the closed-loop sweep advances through speeds but the motor does not physically speed up.

This mode bypasses encoder correction and sends fixed STEP rates directly to the R725:

```text
100, 300, 600, 1000, 3000, 10000, 20000, 35000, 52500 Hz
```

It runs the same rates in positive and negative directions. If the motor speeds up in this mode, the R725/motor/pulse path works and the problem is in the closed-loop command/following logic. If it does not speed up, check R725 settings, wiring, enable/reset, supply, current limit, or pulse generation.

## If your Arduino is not COM5

Edit `upload_and_run_sdc2.bat` and change:

```bat
set PORT=COM5
```

## LED wiring

Use an external LED on D12:

```text
D12 -> 220 or 330 ohm resistor -> LED anode/long leg
LED cathode/short leg -> GND
```

D12 toggles on every actual STEP pulse.

Do not use D13 for the LED because D13 is used as DIR.

## Emergency stop

The Python logger sends `STOP` if you press Ctrl+C, but the safest hard stop is still:

- press Arduino reset, or
- disable/power-cycle the R725.

Closing the terminal alone does not guarantee motor stop unless STOP is sent and received.

## Output

Results are saved in:

```text
SDC2_results/
  SDC2_SWEEP_raw_YYYYMMDD_HHMMSS.csv
  SDC2_clean.csv
  SDC2_trial_summary.csv
  split_trials_csv/
  figures/
```


## New option 4: Open-loop ramped STEP-frequency sweep

Use option 4 when 0.01 deg/s works but higher speed jumps do not. It ramps the STEP frequency instead of jumping directly to each rate. The target frequencies are:

```text
25, 35, 50, 75, 100, 150, 200, 300, 500, 750, 1000, 1500, 3000, 5000 Hz
```

For each target it ramps up for 4 s, holds for 6 s, then ramps down for 3 s. It runs positive and negative directions.


## Option 5: Slow encoder-plot test

Option 5 runs a focused slow-speed encoder validation test at 256 microstepping. It uses:

- 30 s static hold at 50 Hz logging
- 0.002 deg/s for 120 s
- 0.003 deg/s for 120 s
- 0.005 deg/s for 120 s
- 0.010 deg/s for 120 s
- 0.050 deg/s for 120 s
- 0.100 deg/s for 120 s

This is positive direction only to keep the total runtime near 12.5 minutes plus upload/startup time.

Expected encoder count rates at the table are approximately:

- 0.002 deg/s -> 1.37 counts/s
- 0.003 deg/s -> 2.05 counts/s
- 0.005 deg/s -> 3.42 counts/s
- 0.010 deg/s -> 6.85 counts/s
- 0.050 deg/s -> 34.2 counts/s
- 0.100 deg/s -> 68.5 counts/s
