@echo off
cd /d "%~dp0"

echo.
echo ========================================
echo SDC2 FINAL ONE-CLICK UPLOAD AND RUN
echo ========================================
echo.

set PORT=COM5
set BAUD=921600
set FQBN=arduino:mbed_giga:giga
set SKETCH_NAME=SDC2_TestRunner_Menu
set SKETCH_DIR=%~dp0%SKETCH_NAME%

if not exist "%SKETCH_DIR%\%SKETCH_NAME%.ino" (
    echo ERROR: Missing Arduino sketch:
    echo %SKETCH_DIR%\%SKETCH_NAME%.ino
    echo.
    pause
    exit /b 1
)

echo Using port: %PORT%
echo Using baud: %BAUD%
echo Using board FQBN: %FQBN%
echo Sketch folder: %SKETCH_DIR%
echo.

echo Compiling sketch...
arduino-cli compile --fqbn %FQBN% "%SKETCH_DIR%"
if errorlevel 1 (
    echo.
    echo Compile failed.
    pause
    exit /b 1
)

echo.
echo Uploading sketch to Arduino...
arduino-cli upload -p %PORT% --fqbn %FQBN% "%SKETCH_DIR%"
if errorlevel 1 (
    echo.
    echo Upload failed. Check COM port and board connection.
    pause
    exit /b 1
)

echo.
echo Upload complete. Waiting for board reset...
timeout /t 6 /nobreak >nul

echo.
echo Starting SDC2 logger/menu...
python sdc2_logger_plotter.py --port %PORT% --baud %BAUD% --outdir SDC2_results

echo.
echo Done.
pause
