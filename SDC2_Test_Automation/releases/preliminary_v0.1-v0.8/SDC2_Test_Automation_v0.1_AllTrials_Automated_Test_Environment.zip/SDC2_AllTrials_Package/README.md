# SDC2 All-Trials Test Runner Package

This package is for the Arduino/R725/geared-stepper SDC2 setup.

## Files

- `SDC2_AllTrials_TestRunner.ino` - Arduino sketch that runs all SDC2 trials for one physical setup.
- `sdc2_logger_plotter.py` - Python serial logger, CSV splitter, summary generator, and PNG plotter.
- `run_sdc2_all_trials.bat` - Windows batch file to run the serial logger live.
- `plot_existing_sdc2_csv.bat` - Windows batch file to reprocess an existing raw CSV.

## Physical setup labels

Before each run, edit this line in the `.ino` file:

```cpp
const char* RUN_LABEL = "CENTERED_LOADFREE";
```

Use one of:

```text
CENTERED_LOADFREE
OFFSET3IN_LOADFREE
CENTERED_FULLLOAD
OFFSET3IN_FULLLOAD
```

## Run order

1. Upload `SDC2_AllTrials_TestRunner.ino` to the Arduino.
2. Run `run_sdc2_all_trials.bat`.
3. Let it run until `# ALL_TESTS_COMPLETE`.
4. For the 3-inch offset test, physically offset the platform, change `RUN_LABEL`, upload again, and rerun.

## Outputs

The logger creates:

```text
SDC2_results/
  SDC2_all_trials_raw_YYYYMMDD_HHMMSS.csv
  SDC2_all_trials_comments_YYYYMMDD_HHMMSS.txt
  SDC2_all_trials_clean.csv
  SDC2_trial_summary.csv
  split_trials_csv/
  figures/
```

The PNG plots include:

```text
01_fullrun_command_vs_actual_position.png
02_fullrun_following_error.png
03_fullrun_command_vs_measured_speed.png
04_constspeed_error_overlay.png
05_constspeed_speed_bias_vs_target.png
06_constspeed_rms_error_vs_speed.png
07_sine_speed_overlay_test_*.png
08_sine_following_error_overlay.png
09_static_drift_overlay.png
```
