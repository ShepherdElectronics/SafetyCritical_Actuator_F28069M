@echo off
cd /d "%~dp0"

REM Change COM3 if Arduino is on a different port.
python sdc2_logger_plotter.py --port COM3 --baud 115200 --outdir SDC2_results

pause
