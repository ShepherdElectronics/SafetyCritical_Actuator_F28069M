/*
  SDC2 All-Trials Test Runner

  Hardware:
    Arduino GIGA R1 WiFi
    Lin Engineering R725 stepper driver
    Lin Engineering 4118M-06SD-I25-A0-A24F geared stepper
    US Digital E5 encoder on rear motor shaft
    AM26LS32A differential receiver

  Pin map:
    D10 = STEP output to R725 interface
    D13 = DIR output to R725 interface
    D2  = Encoder A from AM26LS32A
    D3  = Encoder B from AM26LS32A
    D4  = Encoder Z / Index from AM26LS32A, logged only

  What this does:
    For one physical configuration, it runs:
      1) static hold, 50 Hz, 180 s
      2) static hold, 100 Hz, 90 s
      3) constant speed positive, ascending speeds, 100 Hz, 60 s each
      4) constant speed positive, descending speeds, 100 Hz, 60 s each
      5) constant speed negative, ascending magnitudes, 100 Hz, 60 s each
      6) constant speed negative, descending magnitudes, 100 Hz, 60 s each
      7) sine velocity tests, 15 deg/s peak, periods 3, 2, 1, 0.5 s, 5 cycles each

  IMPORTANT:
    This is long. Full run is about 37.5 minutes plus transition padding.
    Do centered first. Then physically offset 3 inches, reset Arduino, run again with RUN_LABEL changed.
*/

#define STEP_PIN 10
#define DIR_PIN 13

#define ENC_A 2
#define ENC_B 3
#define ENC_Z 4

// ===== CONFIG LABEL =====
// Change this before each physical setup run.
// Examples: "CENTERED_LOADFREE", "OFFSET3IN_LOADFREE", "CENTERED_FULLLOAD", "OFFSET3IN_FULLLOAD"
const char* RUN_LABEL = "CENTERED_LOADFREE";

// ===== ENCODER / MECHANICAL CONSTANTS =====
const double CPR = 5000.0;
const double EDGE_MULT = 2.0;        // ENC_A CHANGE interrupt => x2 decoding
const double GEAR_RATIO = 24.65;     // motor revs per table rev

const double ENCODER_COUNTS_PER_MOTOR_REV = CPR * EDGE_MULT;
const double ENCODER_COUNTS_PER_TABLE_REV = ENCODER_COUNTS_PER_MOTOR_REV * GEAR_RATIO;

// ===== DRIVER CONSTANTS =====
const double MOTOR_FULL_STEPS_PER_REV = 200.0;
const double MICROSTEP_SETTING = 256.0;

const double DRIVER_PULSES_PER_MOTOR_REV = MOTOR_FULL_STEPS_PER_REV * MICROSTEP_SETTING;
const double DRIVER_PULSES_PER_TABLE_REV = DRIVER_PULSES_PER_MOTOR_REV * GEAR_RATIO;
const double TABLE_DEG_PER_STEP = 360.0 / DRIVER_PULSES_PER_TABLE_REV;

// ===== CLOSED LOOP SETTINGS =====
const double KP_POS = 0.35;
const double MAX_CORRECTION_STEP_RATE_HZ = 250.0;  // higher than old low-speed test so 15 deg/s can run
const unsigned long STEP_PULSE_HIGH_US = 5;        // short pulse supports high speeds better than 100 us
const double RAMP_TIME_SEC = 1.0;

// ===== LOGGING =====
const unsigned long START_DELAY_MS = 10000;

// ===== TEST DURATIONS =====
const unsigned long STATIC_50_MS = 180000UL;
const unsigned long STATIC_100_MS = 90000UL;
const unsigned long CONST_SPEED_MS = 60000UL;
const unsigned long BETWEEN_TEST_MS = 3000UL;

const int NUM_SPEEDS = 7;
const double SPEEDS[NUM_SPEEDS] = {0.01, 0.03, 1.0, 3.0, 5.0, 10.0, 15.0};
const int NUM_SINE_PERIODS = 4;
const double SINE_PERIODS[NUM_SINE_PERIODS] = {3.0, 2.0, 1.0, 0.5};
const double SINE_PEAK_SPEED_DEG_S = 15.0;
const int SINE_CYCLES = 5;

// ===== ENCODER STATE =====
volatile long count = 0;

// ===== GLOBAL TIME =====
unsigned long runStart_us = 0;
unsigned long lastControl_us = 0;
unsigned long lastStep_us = 0;
unsigned long lastLog_us = 0;

// ===== CONTROL STATE =====
double commandTablePosition_deg = 0.0;
double commandTableSpeed_deg_s = 0.0;
double actualMotorPosition_deg = 0.0;
double actualTablePosition_deg = 0.0;
double tablePositionError_deg = 0.0;
double commandedStepRate_Hz = 0.0;

// ===== CURRENT TEST METADATA =====
int testIndex = 0;
const char* currentTestName = "BOOT";
double currentTargetSpeed_deg_s = 0.0;
double currentSinePeriod_s = 0.0;
unsigned long currentTestStart_us = 0;
unsigned long currentLogInterval_us = 10000UL;

void setup() {
  pinMode(STEP_PIN, OUTPUT);
  pinMode(DIR_PIN, OUTPUT);
  pinMode(ENC_A, INPUT);
  pinMode(ENC_B, INPUT);
  pinMode(ENC_Z, INPUT);

  digitalWrite(STEP_PIN, LOW);
  digitalWrite(DIR_PIN, HIGH);

  attachInterrupt(digitalPinToInterrupt(ENC_A), readEncoder, CHANGE);

  Serial.begin(115200);
  delay(2000);

  printHeader();
  Serial.println("# Waiting 10 seconds before starting...");
  delay(START_DELAY_MS);

  runStart_us = micros();
  lastControl_us = runStart_us;
  lastStep_us = runStart_us;
  lastLog_us = runStart_us;

  Serial.println("RunLabel,TestIndex,TestName,Time_s,TestTime_s,SampleRate_Hz,TargetSpeed_deg_s,SinePeriod_s,EncoderCount,CommandTablePosition_deg,ActualMotorPosition_deg,ActualTablePosition_deg,TablePositionError_deg,CommandTableSpeed_deg_s,CommandMotorSpeed_deg_s,StepRate_Hz,EncA,EncB,EncZ");

  runAllTests();

  commandTableSpeed_deg_s = 0.0;
  commandedStepRate_Hz = 0.0;
  Serial.println("# ALL_TESTS_COMPLETE");
}

void loop() {
  // Finished. Keep board alive without issuing steps.
}

void printHeader() {
  Serial.println("# SDC2 All-Trials Test Runner");
  Serial.print("# RUN_LABEL,"); Serial.println(RUN_LABEL);
  Serial.print("# STEP_PIN,"); Serial.println(STEP_PIN);
  Serial.print("# DIR_PIN,"); Serial.println(DIR_PIN);
  Serial.print("# ENC_A,"); Serial.println(ENC_A);
  Serial.print("# ENC_B,"); Serial.println(ENC_B);
  Serial.print("# ENC_Z,"); Serial.println(ENC_Z);
  Serial.print("# CPR,"); Serial.println(CPR, 0);
  Serial.print("# EDGE_MULT,"); Serial.println(EDGE_MULT, 0);
  Serial.print("# GEAR_RATIO,"); Serial.println(GEAR_RATIO, 5);
  Serial.print("# ENCODER_COUNTS_PER_TABLE_REV,"); Serial.println(ENCODER_COUNTS_PER_TABLE_REV, 3);
  Serial.print("# MICROSTEP_SETTING,"); Serial.println(MICROSTEP_SETTING, 0);
  Serial.print("# DRIVER_PULSES_PER_TABLE_REV,"); Serial.println(DRIVER_PULSES_PER_TABLE_REV, 3);
  Serial.print("# TABLE_DEG_PER_STEP,"); Serial.println(TABLE_DEG_PER_STEP, 9);
  Serial.print("# KP_POS,"); Serial.println(KP_POS, 6);
  Serial.print("# MAX_CORRECTION_STEP_RATE_HZ,"); Serial.println(MAX_CORRECTION_STEP_RATE_HZ, 6);
  Serial.println("#");
}

void runAllTests() {
  runTest("STATIC_50HZ_HOLD", 50.0, 0.0, STATIC_50_MS, 0.0);
  runTest("STATIC_100HZ_HOLD", 100.0, 0.0, STATIC_100_MS, 0.0);

  for (int i = 0; i < NUM_SPEEDS; i++) {
    runConstantSpeed("CONST_POS_ASC", SPEEDS[i]);
  }
  for (int i = NUM_SPEEDS - 1; i >= 0; i--) {
    runConstantSpeed("CONST_POS_DESC", SPEEDS[i]);
  }

  for (int i = 0; i < NUM_SPEEDS; i++) {
    runConstantSpeed("CONST_NEG_ASC", -SPEEDS[i]);
  }
  for (int i = NUM_SPEEDS - 1; i >= 0; i--) {
    runConstantSpeed("CONST_NEG_DESC", -SPEEDS[i]);
  }

  for (int i = 0; i < NUM_SINE_PERIODS; i++) {
    runSineVelocity("SINE_VEL", SINE_PERIODS[i]);
  }
}

void runConstantSpeed(const char* name, double speed_deg_s) {
  runTest(name, 100.0, speed_deg_s, CONST_SPEED_MS, 0.0);
}

void runSineVelocity(const char* name, double period_s) {
  unsigned long duration_ms = (unsigned long)(SINE_CYCLES * period_s * 1000.0);
  runTest(name, 100.0, 0.0, duration_ms, period_s);
}

void runTest(const char* name, double sampleRate_Hz, double targetSpeed_deg_s, unsigned long duration_ms, double sinePeriod_s) {
  testIndex++;
  currentTestName = name;
  currentTargetSpeed_deg_s = targetSpeed_deg_s;
  currentSinePeriod_s = sinePeriod_s;
  currentLogInterval_us = (unsigned long)(1000000.0 / sampleRate_Hz);
  currentTestStart_us = micros();
  lastControl_us = currentTestStart_us;
  lastLog_us = currentTestStart_us;

  Serial.print("# START_TEST,");
  Serial.print(testIndex);
  Serial.print(",");
  Serial.print(currentTestName);
  Serial.print(",TargetSpeed,");
  Serial.print(currentTargetSpeed_deg_s, 6);
  Serial.print(",SinePeriod,");
  Serial.print(currentSinePeriod_s, 6);
  Serial.print(",SampleRate,");
  Serial.println(sampleRate_Hz, 3);

  while ((millisSince_us(currentTestStart_us)) < duration_ms) {
    unsigned long now_us = micros();
    updateCommandForCurrentTest(now_us);
    updateClosedLoop(now_us);
    generateStepIfNeeded(now_us);
    logData(now_us, sampleRate_Hz);
  }

  currentTargetSpeed_deg_s = 0.0;
  currentSinePeriod_s = 0.0;
  unsigned long stopStart_us = micros();
  while (millisSince_us(stopStart_us) < BETWEEN_TEST_MS) {
    unsigned long now_us = micros();
    commandTableSpeed_deg_s = 0.0;
    updateClosedLoop(now_us);
    generateStepIfNeeded(now_us);
  }

  Serial.print("# END_TEST,");
  Serial.print(testIndex);
  Serial.print(",");
  Serial.println(currentTestName);
}

unsigned long millisSince_us(unsigned long start_us) {
  return (micros() - start_us) / 1000UL;
}

void updateCommandForCurrentTest(unsigned long now_us) {
  double testTime_s = (now_us - currentTestStart_us) / 1000000.0;

  if (currentSinePeriod_s > 0.0) {
    double omega = 2.0 * PI / currentSinePeriod_s;
    commandTableSpeed_deg_s = SINE_PEAK_SPEED_DEG_S * sin(omega * testTime_s);
  } else {
    double signTarget = currentTargetSpeed_deg_s;
    double rampScale = 1.0;
    if (testTime_s < RAMP_TIME_SEC) {
      rampScale = testTime_s / RAMP_TIME_SEC;
    }
    commandTableSpeed_deg_s = signTarget * rampScale;
  }
}

void updateClosedLoop(unsigned long now_us) {
  double dt_s = (now_us - lastControl_us) / 1000000.0;
  if (dt_s <= 0.0) return;
  lastControl_us = now_us;

  commandTablePosition_deg += commandTableSpeed_deg_s * dt_s;

  long currentCount = getEncoderCount();
  actualMotorPosition_deg = encoderCountToMotorDeg(currentCount);
  actualTablePosition_deg = actualMotorPosition_deg / GEAR_RATIO;
  tablePositionError_deg = commandTablePosition_deg - actualTablePosition_deg;

  double feedforwardStepRate_Hz = commandTableSpeed_deg_s / TABLE_DEG_PER_STEP;
  double correctionStepRate_Hz = (KP_POS * tablePositionError_deg) / TABLE_DEG_PER_STEP;

  if (correctionStepRate_Hz > MAX_CORRECTION_STEP_RATE_HZ) correctionStepRate_Hz = MAX_CORRECTION_STEP_RATE_HZ;
  if (correctionStepRate_Hz < -MAX_CORRECTION_STEP_RATE_HZ) correctionStepRate_Hz = -MAX_CORRECTION_STEP_RATE_HZ;

  commandedStepRate_Hz = feedforwardStepRate_Hz + correctionStepRate_Hz;
}

void generateStepIfNeeded(unsigned long now_us) {
  if (commandedStepRate_Hz == 0.0) return;

  bool forward = commandedStepRate_Hz > 0.0;
  double absStepRate_Hz = abs(commandedStepRate_Hz);
  if (absStepRate_Hz < 0.001) return;

  unsigned long stepInterval_us = (unsigned long)(1000000.0 / absStepRate_Hz);
  if (stepInterval_us < (STEP_PULSE_HIGH_US + 2)) {
    stepInterval_us = STEP_PULSE_HIGH_US + 2;
  }

  if (now_us - lastStep_us >= stepInterval_us) {
    digitalWrite(DIR_PIN, forward ? HIGH : LOW);
    digitalWrite(STEP_PIN, HIGH);
    delayMicroseconds(STEP_PULSE_HIGH_US);
    digitalWrite(STEP_PIN, LOW);
    lastStep_us = micros();
  }
}

void logData(unsigned long now_us, double sampleRate_Hz) {
  if (now_us - lastLog_us < currentLogInterval_us) return;

  long currentCount = getEncoderCount();
  double motor_deg = encoderCountToMotorDeg(currentCount);
  double table_deg = motor_deg / GEAR_RATIO;
  double table_error_deg = commandTablePosition_deg - table_deg;
  double command_motor_speed_deg_s = commandTableSpeed_deg_s * GEAR_RATIO;
  double runTime_s = (now_us - runStart_us) / 1000000.0;
  double testTime_s = (now_us - currentTestStart_us) / 1000000.0;

  Serial.print(RUN_LABEL);
  Serial.print(",");
  Serial.print(testIndex);
  Serial.print(",");
  Serial.print(currentTestName);
  Serial.print(",");
  Serial.print(runTime_s, 6);
  Serial.print(",");
  Serial.print(testTime_s, 6);
  Serial.print(",");
  Serial.print(sampleRate_Hz, 3);
  Serial.print(",");
  Serial.print(currentTargetSpeed_deg_s, 6);
  Serial.print(",");
  Serial.print(currentSinePeriod_s, 6);
  Serial.print(",");
  Serial.print(currentCount);
  Serial.print(",");
  Serial.print(commandTablePosition_deg, 6);
  Serial.print(",");
  Serial.print(motor_deg, 6);
  Serial.print(",");
  Serial.print(table_deg, 6);
  Serial.print(",");
  Serial.print(table_error_deg, 6);
  Serial.print(",");
  Serial.print(commandTableSpeed_deg_s, 6);
  Serial.print(",");
  Serial.print(command_motor_speed_deg_s, 6);
  Serial.print(",");
  Serial.print(commandedStepRate_Hz, 6);
  Serial.print(",");
  Serial.print(digitalRead(ENC_A));
  Serial.print(",");
  Serial.print(digitalRead(ENC_B));
  Serial.print(",");
  Serial.println(digitalRead(ENC_Z));

  lastLog_us += currentLogInterval_us;
}

void readEncoder() {
  if (digitalRead(ENC_A) == digitalRead(ENC_B)) {
    count--;
  } else {
    count++;
  }
}

long getEncoderCount() {
  noInterrupts();
  long c = count;
  interrupts();
  return c;
}

double encoderCountToMotorDeg(long encoderCount) {
  return (encoderCount * 360.0) / ENCODER_COUNTS_PER_MOTOR_REV;
}
