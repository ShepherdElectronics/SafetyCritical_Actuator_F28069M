@echo off
cd /d "%~dp0"

REM Usage: drag a raw CSV onto this BAT file, or run: plot_existing_sdc2_csv.bat path\to\file.csv
if "%~1"=="" (
  echo Drag a raw SDC2 CSV onto this BAT file, or pass the CSV path as an argument.
  pause
  exit /b 1
)

python sdc2_logger_plotter.py --csv "%~1" --outdir SDC2_reprocessed_results
pause
