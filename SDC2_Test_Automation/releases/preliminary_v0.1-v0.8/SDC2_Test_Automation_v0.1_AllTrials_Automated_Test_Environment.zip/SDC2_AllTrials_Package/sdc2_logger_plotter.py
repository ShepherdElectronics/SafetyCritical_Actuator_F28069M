import argparse
import datetime as dt
import time
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import serial

EXPECTED_COLUMNS = [
    "RunLabel", "TestIndex", "TestName", "Time_s", "TestTime_s", "SampleRate_Hz",
    "TargetSpeed_deg_s", "SinePeriod_s", "EncoderCount", "CommandTablePosition_deg",
    "ActualMotorPosition_deg", "ActualTablePosition_deg", "TablePositionError_deg",
    "CommandTableSpeed_deg_s", "CommandMotorSpeed_deg_s", "StepRate_Hz",
    "EncA", "EncB", "EncZ",
]


def slug(x: str) -> str:
    return str(x).replace(" ", "_").replace(".", "p").replace("-", "neg").replace("/", "_").replace("+", "pos")


def read_serial_to_csv(port: str, baud: int, outdir: Path, timeout_s: float = 3.0) -> Path:
    outdir.mkdir(parents=True, exist_ok=True)
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    raw_path = outdir / f"SDC2_all_trials_raw_{timestamp}.csv"
    comment_path = outdir / f"SDC2_all_trials_comments_{timestamp}.txt"

    print(f"Opening {port} at {baud} baud...")
    print("Press Ctrl+C after # ALL_TESTS_COMPLETE, or any time you need to abort.")

    header_seen = False
    last_data_time = time.time()

    with serial.Serial(port, baud, timeout=1) as ser, raw_path.open("w", newline="") as fout, comment_path.open("w") as fcomment:
        ser.reset_input_buffer()
        while True:
            try:
                raw = ser.readline().decode("utf-8", errors="replace").strip()
            except KeyboardInterrupt:
                print("\nStopped by user.")
                break

            if not raw:
                if header_seen and (time.time() - last_data_time) > timeout_s:
                    pass
                continue

            print(raw)

            if raw.startswith("#"):
                fcomment.write(raw + "\n")
                fcomment.flush()
                if "ALL_TESTS_COMPLETE" in raw:
                    print("All tests complete. Closing log.")
                    break
                continue

            if raw.startswith("RunLabel,TestIndex,TestName"):
                fout.write(raw + "\n")
                fout.flush()
                header_seen = True
                last_data_time = time.time()
                continue

            if header_seen:
                fout.write(raw + "\n")
                fout.flush()
                last_data_time = time.time()

    print(f"Saved raw CSV: {raw_path}")
    return raw_path


def load_data(csv_path: Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing expected columns: {missing}")

    for col in EXPECTED_COLUMNS:
        if col not in ["RunLabel", "TestName"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["Time_s", "TestIndex", "CommandTablePosition_deg", "ActualTablePosition_deg"])

    def measured_speed(group: pd.DataFrame) -> pd.Series:
        if len(group) <= 2:
            return pd.Series(np.nan, index=group.index)
        t = group["TestTime_s"].to_numpy()
        x = group["ActualTablePosition_deg"].to_numpy()
        return pd.Series(np.gradient(x, t), index=group.index)

    df["MeasuredTableSpeed_deg_s"] = df.groupby("TestIndex", group_keys=False).apply(measured_speed)
    df["AbsError_deg"] = df["TablePositionError_deg"].abs()
    return df


def split_trials(df: pd.DataFrame, outdir: Path) -> None:
    split_dir = outdir / "split_trials_csv"
    split_dir.mkdir(parents=True, exist_ok=True)
    for tid, g in df.groupby("TestIndex"):
        name = g["TestName"].iloc[0]
        target = g["TargetSpeed_deg_s"].iloc[0]
        period = g["SinePeriod_s"].iloc[0]
        run_label = g["RunLabel"].iloc[0]
        file_name = f"{int(tid):03d}_{slug(run_label)}_{slug(name)}_spd_{target:+.3f}_period_{period:.3f}.csv"
        g.to_csv(split_dir / file_name, index=False)


def save_summary(df: pd.DataFrame, outdir: Path) -> pd.DataFrame:
    rows = []
    for tid, g in df.groupby("TestIndex"):
        rows.append({
            "TestIndex": int(tid),
            "RunLabel": g["RunLabel"].iloc[0],
            "TestName": g["TestName"].iloc[0],
            "TargetSpeed_deg_s": g["TargetSpeed_deg_s"].iloc[0],
            "SinePeriod_s": g["SinePeriod_s"].iloc[0],
            "SampleRate_Hz": g["SampleRate_Hz"].median(),
            "Duration_s": g["TestTime_s"].max() - g["TestTime_s"].min(),
            "N": len(g),
            "MeanMeasuredSpeed_deg_s": g["MeasuredTableSpeed_deg_s"].mean(),
            "StdMeasuredSpeed_deg_s": g["MeasuredTableSpeed_deg_s"].std(),
            "MeanError_deg": g["TablePositionError_deg"].mean(),
            "RMSError_deg": np.sqrt(np.mean(g["TablePositionError_deg"] ** 2)),
            "MaxAbsError_deg": g["AbsError_deg"].max(),
            "FinalCommandPosition_deg": g["CommandTablePosition_deg"].iloc[-1],
            "FinalActualPosition_deg": g["ActualTablePosition_deg"].iloc[-1],
            "FinalError_deg": g["TablePositionError_deg"].iloc[-1],
            "MeanStepRate_Hz": g["StepRate_Hz"].mean(),
        })
    summary = pd.DataFrame(rows)
    summary.to_csv(outdir / "SDC2_trial_summary.csv", index=False)
    return summary


def fig_path(outdir: Path, name: str) -> Path:
    plot_dir = outdir / "figures"
    plot_dir.mkdir(parents=True, exist_ok=True)
    return plot_dir / name


def plot_all(df: pd.DataFrame, summary: pd.DataFrame, outdir: Path) -> None:
    plt.figure(figsize=(14, 7))
    plt.plot(df["Time_s"], df["CommandTablePosition_deg"], label="Command position")
    plt.plot(df["Time_s"], df["ActualTablePosition_deg"], label="Actual encoder-derived position", alpha=0.8)
    plt.xlabel("Run time [s]")
    plt.ylabel("Table position [deg]")
    plt.title("SDC2 Full Run: Commanded vs Actual Table Position")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(fig_path(outdir, "01_fullrun_command_vs_actual_position.png"), dpi=200)
    plt.close()

    plt.figure(figsize=(14, 6))
    plt.plot(df["Time_s"], df["TablePositionError_deg"])
    plt.xlabel("Run time [s]")
    plt.ylabel("Position error [deg]")
    plt.title("SDC2 Full Run: Following Error")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(fig_path(outdir, "02_fullrun_following_error.png"), dpi=200)
    plt.close()

    plt.figure(figsize=(14, 6))
    plt.plot(df["Time_s"], df["CommandTableSpeed_deg_s"], label="Command speed")
    plt.plot(df["Time_s"], df["MeasuredTableSpeed_deg_s"], label="Measured speed from encoder", alpha=0.6)
    plt.xlabel("Run time [s]")
    plt.ylabel("Speed [deg/s]")
    plt.title("SDC2 Full Run: Commanded vs Measured Speed")
    plt.legend()
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(fig_path(outdir, "03_fullrun_command_vs_measured_speed.png"), dpi=200)
    plt.close()

    const_df = df[df["TestName"].str.contains("CONST", na=False)].copy()
    if not const_df.empty:
        plt.figure(figsize=(14, 7))
        for tid, g in const_df.groupby("TestIndex"):
            label = f"{int(tid)} {g['TestName'].iloc[0]} {g['TargetSpeed_deg_s'].iloc[0]:+.2f} dps"
            plt.plot(g["TestTime_s"], g["TablePositionError_deg"], label=label, linewidth=0.8)
        plt.xlabel("Trial time [s]")
        plt.ylabel("Position error [deg]")
        plt.title("Constant-Speed Trials Overlay: Following Error")
        plt.grid(True)
        plt.legend(fontsize=7, ncol=2)
        plt.tight_layout()
        plt.savefig(fig_path(outdir, "04_constspeed_error_overlay.png"), dpi=200)
        plt.close()

        const_summary = summary[summary["TestName"].str.contains("CONST", na=False)].copy()
        const_summary["SpeedError_deg_s"] = const_summary["MeanMeasuredSpeed_deg_s"] - const_summary["TargetSpeed_deg_s"]
        plt.figure(figsize=(10, 6))
        for name, g in const_summary.groupby("TestName"):
            plt.scatter(g["TargetSpeed_deg_s"], g["SpeedError_deg_s"], label=name)
        plt.axhline(0, linewidth=1)
        plt.xlabel("Target speed [deg/s]")
        plt.ylabel("Mean measured speed - target [deg/s]")
        plt.title("Constant-Speed Bias: Speed Error vs Target Speed")
        plt.grid(True)
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(fig_path(outdir, "05_constspeed_speed_bias_vs_target.png"), dpi=200)
        plt.close()

        plt.figure(figsize=(10, 6))
        for name, g in const_summary.groupby("TestName"):
            plt.scatter(g["TargetSpeed_deg_s"].abs(), g["RMSError_deg"], label=name)
        plt.xlabel("Absolute target speed [deg/s]")
        plt.ylabel("RMS position error [deg]")
        plt.title("Constant-Speed Accuracy: RMS Error vs Speed")
        plt.grid(True)
        plt.legend(fontsize=8)
        plt.tight_layout()
        plt.savefig(fig_path(outdir, "06_constspeed_rms_error_vs_speed.png"), dpi=200)
        plt.close()

    sine_df = df[df["TestName"].str.contains("SINE", na=False)].copy()
    if not sine_df.empty:
        for tid, g in sine_df.groupby("TestIndex"):
            period = g["SinePeriod_s"].iloc[0]
            plt.figure(figsize=(12, 6))
            plt.plot(g["TestTime_s"], g["CommandTableSpeed_deg_s"], label="Command speed")
            plt.plot(g["TestTime_s"], g["MeasuredTableSpeed_deg_s"], label="Measured speed", alpha=0.7)
            plt.xlabel("Trial time [s]")
            plt.ylabel("Speed [deg/s]")
            plt.title(f"Sine Velocity Trial: period = {period:.3f} s")
            plt.grid(True)
            plt.legend()
            plt.tight_layout()
            plt.savefig(fig_path(outdir, f"07_sine_speed_overlay_test_{int(tid):03d}_period_{period:.3f}s.png"), dpi=200)
            plt.close()

        plt.figure(figsize=(12, 6))
        for tid, g in sine_df.groupby("TestIndex"):
            period = g["SinePeriod_s"].iloc[0]
            plt.plot(g["TestTime_s"], g["TablePositionError_deg"], label=f"T={period:.1f}s")
        plt.xlabel("Trial time [s]")
        plt.ylabel("Position error [deg]")
        plt.title("Sine Velocity Trials: Following Error Overlay")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_path(outdir, "08_sine_following_error_overlay.png"), dpi=200)
        plt.close()

    static_df = df[df["TestName"].str.contains("STATIC", na=False)].copy()
    if not static_df.empty:
        plt.figure(figsize=(12, 6))
        for tid, g in static_df.groupby("TestIndex"):
            label = f"{g['TestName'].iloc[0]}"
            relative_pos = g["ActualTablePosition_deg"] - g["ActualTablePosition_deg"].iloc[0]
            plt.plot(g["TestTime_s"], relative_pos, label=label)
        plt.xlabel("Trial time [s]")
        plt.ylabel("Relative table position drift [deg]")
        plt.title("Static Tests: Encoder-Derived Drift")
        plt.grid(True)
        plt.legend()
        plt.tight_layout()
        plt.savefig(fig_path(outdir, "09_static_drift_overlay.png"), dpi=200)
        plt.close()


def main():
    parser = argparse.ArgumentParser(description="Log and plot SDC2 all-trials Arduino output.")
    parser.add_argument("--port", default="COM3", help="Serial port, e.g. COM3")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--outdir", default="SDC2_results", help="Output folder")
    parser.add_argument("--csv", default=None, help="Analyze an existing CSV instead of logging serial")
    args = parser.parse_args()

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    if args.csv:
        csv_path = Path(args.csv)
    else:
        csv_path = read_serial_to_csv(args.port, args.baud, outdir)

    df = load_data(csv_path)
    clean_path = outdir / "SDC2_all_trials_clean.csv"
    df.to_csv(clean_path, index=False)
    split_trials(df, outdir)
    summary = save_summary(df, outdir)
    plot_all(df, summary, outdir)

    print(f"Clean CSV: {clean_path}")
    print(f"Summary: {outdir / 'SDC2_trial_summary.csv'}")
    print(f"Split CSVs: {outdir / 'split_trials_csv'}")
    print(f"Figures: {outdir / 'figures'}")


if __name__ == "__main__":
    main()
