# Real-time target changes in this package

This package moves the SDC2 firmware closer to a real-time target/host model.

## Target-side changes

- Added a 1 kHz profile/control tick (`CONTROL_PERIOD_US = 1000`).
- Split the speed signals into separate columns:
  - `TargetSpeed_deg_s`: requested signed segment speed, constant during a trial.
  - `ProfileSpeed_deg_s`: ramp/sine-limited trajectory speed.
  - `StepCommandSpeed_deg_s`: speed implied by the final STEP timer frequency.
  - `MeasuredSpeed_deg_s`: encoder-derived measured speed.
- Replaced the old catch-up burst step accumulator with a nonblocking one-pulse-at-a-time step scheduler.
- Late STEP service now increments `StepBacklogDrops` and reschedules instead of bursting pulses.
- Telemetry can be dropped when STEP service is already late; drops are counted in `TelemetryDrops`.
- Trial transitions reset target/profile/step-command variables to prevent stale one-row command spikes.
- Direction changes include a short DIR setup delay before stepping.
- Trial segments remain time-bounded, so characterization windows end by elapsed time.

## Host/postprocessing changes

- Logger and GUI header fallback updated for the expanded real-time CSV format.
- Live speed plot now uses `ProfileSpeed_deg_s` rather than treating the constant target as the instantaneous command.
- Postprocessing uses `HOLD_SPEED` rows for constant-speed performance metrics when available.
- Figures and summaries therefore avoid ramp-up/ramp-down artifacts when computing speed tracking.

## Important note

This is still bare-metal cooperative real-time firmware, not an RTOS. The STEP scheduler is nonblocking and much safer than the previous burst-catch-up approach, but a true hardware timer ISR would be the next upgrade if the platform needs tighter pulse timing at higher step rates.
