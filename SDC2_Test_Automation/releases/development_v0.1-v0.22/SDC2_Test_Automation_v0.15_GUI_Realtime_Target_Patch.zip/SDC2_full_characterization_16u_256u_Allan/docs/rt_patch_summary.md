# RT patch summary

This package implements the requested real-time target/host changes from the real-time system checklist.

## Implemented in Arduino firmware

- 1 kHz profile/control tick using `CONTROL_PERIOD_US`.
- Nonblocking STEP scheduler that emits at most one pulse per service call.
- Removed burst-style catch-up stepping that could make the table speed up after latency.
- STEP lateness is counted in `StepBacklogDrops` and flagged as `WARN_STEP_LATE_DROP`.
- Telemetry can be dropped when STEP service is already late; drops are counted in `TelemetryDrops`.
- Segment transitions reset target/profile/step speed variables.
- Direction changes re-arm the step scheduler and include a short DIR setup delay.
- CSV now separates:
  - `TargetSpeed_deg_s`
  - `ProfileSpeed_deg_s`
  - `StepCommandSpeed_deg_s`
  - `MeasuredSpeed_deg_s`

## Implemented in Python host

- Logger and GUI understand the expanded CSV format.
- Header synthesis works with the new column count.
- Live speed plot uses profile/step command rather than a stale target-speed signal.
- Postprocessor uses `HOLD_SPEED` rows for constant-speed metrics when available.
- Documentation added in `docs/real_time_target_changes.md`.

## Use recommendation

Start with:

- Trial length: `super_short`
- Telemetry rate: `20 Hz`
- Command: `D`

Then run protocol tests with 10 or 20 Hz telemetry before trying higher telemetry rates.
