# File manifest

## Root scripts

- `upload_arduino_cli.bat` - compile/upload the Arduino sketch with Arduino CLI.
- `run_debug_logger.bat` - run short debug test.
- `run_protocol_logger.bat` - run official protocol constants.
- `run_highspeed_10_50_logger.bat` - run 10-50 deg/s extension.
- `run_postprocess_example.bat` - example postprocess command.

## Arduino

- `arduino/SDC2_FullChar_16u/SDC2_FullChar_16u.ino` - full characterization firmware, already set to 16 microsteps.

## Python

- `python/sdc2_serial_logger.py` - serial CSV logger.
- `python/sdc2_postprocess_fullchar.py` - one-folder plot/summary postprocessor.

## MATLAB

- `matlab/Plot_All_SDC2_Event_Timing_Final_OneFolder.m` - raw event timing plots.
- `matlab/Analyze_SDC2_Full_Characterization_16u.m` - summary plots.

## Docs

- `docs/README.md` - package overview.
- `docs/SDC2_16ustep_quick_start.md` - step-by-step use.
- `docs/SDC2_16ustep_test_plan.md` - recommended test plan.
- `docs/file_manifest.md` - this file.

## Reference

- `reference/Testing_Protocol_SCD_Phases_1_and_2.txt` - uploaded test protocol text.
- `reference/Conversation_Context_SDC2.txt` - prior working notes and context.
- `reference/SDC2_256ustep_TI_Style_Report_Labeled_Review.pdf` - previous 256-ustep report for comparison.
- `reference/256ustep_Event_Analysis_Combined_Summary.png` - previous 256-ustep summary figure.
- `reference/256ustep_Event_Annotated_Target_0p010000_deg_s.png` - previous 0.01 deg/s event figure.
