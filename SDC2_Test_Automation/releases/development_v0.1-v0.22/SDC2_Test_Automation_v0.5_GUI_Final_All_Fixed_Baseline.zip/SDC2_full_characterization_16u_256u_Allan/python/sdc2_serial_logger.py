#!/usr/bin/env python3
"""
SDC2 serial logger for Arduino firmware.

Commands sent to Arduino:
  D debug
  S static tests
  P official protocol constants
  H high-speed 10-50 deg/s
  N sine tests
  A all final tests

Robust behavior:
  - Stops automatically on single-test completion markers, not only ALL_TESTS_COMPLETE.
  - Keeps serial comments in *_metadata.txt.
  - Refuses to silently accept an empty/no-header CSV.
"""

import argparse
import csv
import os
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    import serial
except ImportError:
    print("ERROR: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
    raise

DONE_MARKERS = [
    "ALL_TESTS_COMPLETE",
    "Debug test complete",
    "Static tests complete",
    "Official protocol constant-speed tests complete",
    "High-speed characterization complete",
    "Sine tests complete",
]

HEADER_STARTS = (
    "Time_s",
    "RunLabel,Mode,TestIndex,TestName",
)


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--port", required=True, help="Serial port, e.g. COM5")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--command", default="?", help="Arduino command to send: D,S,P,H,N,A,Z,?")
    p.add_argument("--output", default="", help="Output CSV path. Default uses timestamp in runs/.")
    p.add_argument("--timeout", type=float, default=2.0)
    p.add_argument("--max-seconds", type=float, default=0.0, help="Optional forced stop/logging duration. 0 = until done marker/Ctrl+C.")
    return p.parse_args()


def looks_like_header(line: str) -> bool:
    return any(line.startswith(h) for h in HEADER_STARTS)


def validate_csv(path: Path, rows: int, header):
    if not path.exists() or path.stat().st_size == 0:
        raise RuntimeError(
            f"Raw CSV is empty or missing: {path}\n"
            "No CSV header/data was captured. Check COM port, baud, firmware command, and that the test actually started."
        )
    if header is None:
        raise RuntimeError(
            f"Raw CSV was created but no CSV header was seen: {path}\n"
            "The Arduino printed comments/status but no data header. Do not postprocess this file."
        )
    if rows <= 0:
        raise RuntimeError(
            f"Raw CSV has a header but zero data rows: {path}\n"
            "Run the test longer or use a completed non-empty CSV."
        )


def main():
    args = parse_args()

    if not args.output:
        os.makedirs("runs", exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        args.output = os.path.join("runs", f"sdc2_{args.command}_{stamp}.csv")
    else:
        outdir = os.path.dirname(args.output)
        if outdir:
            os.makedirs(outdir, exist_ok=True)

    out_path = Path(args.output)
    print(f"Opening {args.port} at {args.baud} baud")
    print(f"Output CSV: {out_path}")

    ser = serial.Serial(args.port, args.baud, timeout=args.timeout)
    time.sleep(2.5)
    ser.reset_input_buffer()

    cmd = args.command.strip().upper()
    print(f"Sending command: {cmd}")
    ser.write((cmd + "\n").encode("ascii"))
    ser.flush()

    start = time.time()
    csv_started = False
    header = None
    rows = 0
    comments = []
    completion_marker = ""

    try:
        with out_path.open("w", newline="", encoding="utf-8") as f:
            writer = None
            try:
                while True:
                    if args.max_seconds > 0 and (time.time() - start) > args.max_seconds:
                        print("Max seconds reached. Sending stop command X.")
                        ser.write(b"X\n")
                        ser.flush()
                        comments.append("# LOGGER_MAX_SECONDS_REACHED")
                        break

                    raw = ser.readline()
                    if not raw:
                        continue
                    line = raw.decode("utf-8", errors="replace").strip()
                    if not line:
                        continue

                    print(line)

                    if line.startswith("#"):
                        comments.append(line)
                        for marker in DONE_MARKERS:
                            if marker in line:
                                completion_marker = marker
                                print(f"Completion marker seen: {marker}")
                                raise StopIteration
                        continue

                    if looks_like_header(line):
                        header = [x.strip() for x in line.split(",")]
                        writer = csv.writer(f)
                        writer.writerow(header)
                        f.flush()
                        csv_started = True
                        continue

                    parts = [x.strip() for x in line.split(",")]
                    if csv_started and writer is not None:
                        if len(parts) == len(header):
                            writer.writerow(parts)
                            rows += 1
                            if rows % 100 == 0:
                                f.flush()
                        else:
                            comments.append("# MALFORMED," + line)
                    else:
                        # Numeric row before header: preserve as comment so the problem is visible.
                        comments.append("# DATA_BEFORE_HEADER," + line)
            except StopIteration:
                pass
            except KeyboardInterrupt:
                print("\nCtrl+C received. Sending stop command X.")
                comments.append("# LOGGER_KEYBOARD_INTERRUPT")
                try:
                    ser.write(b"X\n")
                    ser.flush()
                except Exception:
                    pass
            finally:
                f.flush()
    finally:
        ser.close()

    meta_path = out_path.with_name(out_path.stem + "_metadata.txt")
    with meta_path.open("w", encoding="utf-8") as mf:
        mf.write(f"port={args.port}\n")
        mf.write(f"baud={args.baud}\n")
        mf.write(f"command={cmd}\n")
        mf.write(f"output={out_path}\n")
        mf.write(f"rows={rows}\n")
        mf.write(f"header_seen={header is not None}\n")
        mf.write(f"completion_marker={completion_marker}\n")
        mf.write("\n# Serial comments\n")
        for c in comments:
            mf.write(c + "\n")

    print(f"Saved CSV: {out_path}")
    print(f"Rows: {rows}")
    print(f"Saved metadata: {meta_path}")

    try:
        validate_csv(out_path, rows, header)
    except RuntimeError as e:
        print("ERROR:", e, file=sys.stderr)
        sys.exit(2)


if __name__ == "__main__":
    main()
