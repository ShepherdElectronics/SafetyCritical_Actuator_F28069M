#!/usr/bin/env python3
"""
SDC2 Characterization UI Launcher

Tkinter desktop UI for:
  - selecting 16 or 256 microstep firmware
  - Arduino CLI compile/upload
  - running SDC2 serial logger commands D/S/P/H/N/A
  - running event postprocess figures
  - running Allan deviation analysis figures

No external GUI packages required. Uses Python standard library tkinter.
Requires for logging/analysis:
  pip install pyserial pandas numpy matplotlib
"""

import datetime as dt
import os
import queue
import subprocess
import sys
import threading
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_TITLE = "SDC2 Characterization UI"

DEFAULT_PORT = "COM5"
DEFAULT_FQBN = "arduino:mbed_giga:giga"
DEFAULT_BAUD = "115200"  # full-characterization logger/sketch default

COMMANDS = {
    "D": "Debug shakedown",
    "S": "Static Allan hold tests",
    "P": "Protocol constant-speed tests",
    "H": "High-speed 10-50 deg/s test",
    "N": "Sine velocity tests",
    "A": "ALL main tests",
}

ROOT = Path(__file__).resolve().parent
PY = sys.executable or "python"


def now_stamp():
    return dt.datetime.now().strftime("%Y%m%d_%H%M%S")


class SDC2UI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry("1100x760")
        self.minsize(920, 620)

        self.process = None
        self.log_queue = queue.Queue()
        self.worker_thread = None
        self.last_csv = tk.StringVar(value="")
        self.last_run_dir = tk.StringVar(value="")

        self.port = tk.StringVar(value=DEFAULT_PORT)
        self.fqbn = tk.StringVar(value=DEFAULT_FQBN)
        self.baud = tk.StringVar(value=DEFAULT_BAUD)
        self.microstep = tk.StringVar(value="16")
        self.command = tk.StringVar(value="D")
        self.auto_postprocess = tk.BooleanVar(value=True)
        self.auto_allan = tk.BooleanVar(value=True)
        self.max_seconds = tk.StringVar(value="0")

        self._build_ui()
        self.after(100, self._drain_log_queue)

    def _build_ui(self):
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        title = ttk.Label(self, text="SDC2 Characterization UI", font=("Segoe UI", 18, "bold"))
        title.grid(row=0, column=0, sticky="w", padx=14, pady=(12, 4))

        main = ttk.Frame(self)
        main.grid(row=1, column=0, sticky="ew", padx=14, pady=6)
        for c in range(8):
            main.columnconfigure(c, weight=1)

        # Settings frame
        settings = ttk.LabelFrame(main, text="Connection / firmware")
        settings.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=(0, 8), pady=4)
        for c in range(4): settings.columnconfigure(c, weight=1)

        ttk.Label(settings, text="Port").grid(row=0, column=0, sticky="w", padx=8, pady=(8,2))
        ttk.Entry(settings, textvariable=self.port, width=12).grid(row=1, column=0, sticky="ew", padx=8, pady=(0,8))

        ttk.Label(settings, text="Baud").grid(row=0, column=1, sticky="w", padx=8, pady=(8,2))
        ttk.Entry(settings, textvariable=self.baud, width=12).grid(row=1, column=1, sticky="ew", padx=8, pady=(0,8))

        ttk.Label(settings, text="Board FQBN").grid(row=0, column=2, sticky="w", padx=8, pady=(8,2))
        ttk.Entry(settings, textvariable=self.fqbn, width=28).grid(row=1, column=2, columnspan=2, sticky="ew", padx=8, pady=(0,8))

        ttk.Label(settings, text="Microstep firmware").grid(row=2, column=0, sticky="w", padx=8, pady=(4,2))
        ttk.Radiobutton(settings, text="16 µstep", variable=self.microstep, value="16").grid(row=3, column=0, sticky="w", padx=8, pady=(0,8))
        ttk.Radiobutton(settings, text="256 µstep", variable=self.microstep, value="256").grid(row=3, column=1, sticky="w", padx=8, pady=(0,8))

        ttk.Button(settings, text="Compile selected firmware", command=self.compile_firmware).grid(row=2, column=2, sticky="ew", padx=8, pady=4)
        ttk.Button(settings, text="Upload selected firmware", command=self.upload_firmware).grid(row=2, column=3, sticky="ew", padx=8, pady=4)
        ttk.Button(settings, text="Compile + upload", command=self.compile_upload_firmware).grid(row=3, column=2, columnspan=2, sticky="ew", padx=8, pady=(0,8))

        # Run frame
        runf = ttk.LabelFrame(main, text="Run tests")
        runf.grid(row=0, column=4, columnspan=4, sticky="nsew", padx=(8, 0), pady=4)
        for c in range(4): runf.columnconfigure(c, weight=1)

        ttk.Label(runf, text="Test command").grid(row=0, column=0, sticky="w", padx=8, pady=(8,2))
        cmd_box = ttk.Combobox(runf, textvariable=self.command, values=[f"{k} - {v}" for k,v in COMMANDS.items()], state="readonly")
        cmd_box.grid(row=1, column=0, columnspan=4, sticky="ew", padx=8, pady=(0,8))
        cmd_box.current(0)
        cmd_box.bind("<<ComboboxSelected>>", self._command_combo_changed)

        ttk.Checkbutton(runf, text="Auto postprocess event plots", variable=self.auto_postprocess).grid(row=2, column=0, columnspan=2, sticky="w", padx=8)
        ttk.Checkbutton(runf, text="Auto Allan analysis", variable=self.auto_allan).grid(row=2, column=2, columnspan=2, sticky="w", padx=8)

        ttk.Label(runf, text="Max seconds, 0 = until firmware complete/Ctrl stop").grid(row=3, column=0, columnspan=2, sticky="w", padx=8, pady=(6,2))
        ttk.Entry(runf, textvariable=self.max_seconds, width=10).grid(row=3, column=2, sticky="ew", padx=8, pady=(6,2))

        ttk.Button(runf, text="Run selected test", command=self.run_selected_test).grid(row=4, column=0, columnspan=2, sticky="ew", padx=8, pady=8)
        ttk.Button(runf, text="Compile/upload + run", command=self.compile_upload_run).grid(row=4, column=2, columnspan=2, sticky="ew", padx=8, pady=8)

        # File/actions row
        actions = ttk.Frame(self)
        actions.grid(row=3, column=0, sticky="ew", padx=14, pady=8)
        for c in range(7): actions.columnconfigure(c, weight=1)

        ttk.Button(actions, text="Analyze existing CSV", command=self.analyze_existing_csv).grid(row=0, column=0, sticky="ew", padx=4)
        ttk.Button(actions, text="Run Allan on existing CSV", command=self.allan_existing_csv).grid(row=0, column=1, sticky="ew", padx=4)
        ttk.Button(actions, text="Open last run folder", command=self.open_last_run_folder).grid(row=0, column=2, sticky="ew", padx=4)
        ttk.Button(actions, text="Open root folder", command=self.open_root_folder).grid(row=0, column=3, sticky="ew", padx=4)
        ttk.Button(actions, text="Stop/kill running process", command=self.stop_process).grid(row=0, column=4, sticky="ew", padx=4)
        ttk.Button(actions, text="Clear log", command=lambda: self.log_text.delete("1.0", tk.END)).grid(row=0, column=5, sticky="ew", padx=4)
        ttk.Button(actions, text="Quit", command=self.destroy).grid(row=0, column=6, sticky="ew", padx=4)

        # Status
        status = ttk.LabelFrame(self, text="Last output")
        status.grid(row=4, column=0, sticky="ew", padx=14, pady=(0,8))
        status.columnconfigure(1, weight=1)
        ttk.Label(status, text="Last CSV:").grid(row=0, column=0, sticky="w", padx=8, pady=2)
        ttk.Label(status, textvariable=self.last_csv).grid(row=0, column=1, sticky="ew", padx=8, pady=2)
        ttk.Label(status, text="Last run dir:").grid(row=1, column=0, sticky="w", padx=8, pady=2)
        ttk.Label(status, textvariable=self.last_run_dir).grid(row=1, column=1, sticky="ew", padx=8, pady=2)

        # Log area
        log_frame = ttk.LabelFrame(self, text="Live log")
        log_frame.grid(row=2, column=0, sticky="nsew", padx=14, pady=6)
        log_frame.rowconfigure(0, weight=1)
        log_frame.columnconfigure(0, weight=1)

        self.log_text = tk.Text(log_frame, wrap="word", font=("Consolas", 10))
        self.log_text.grid(row=0, column=0, sticky="nsew")
        scrollbar = ttk.Scrollbar(log_frame, orient="vertical", command=self.log_text.yview)
        scrollbar.grid(row=0, column=1, sticky="ns")
        self.log_text.configure(yscrollcommand=scrollbar.set)

        self.log("Ready. Pick 16 or 256 µstep, compile/upload, then run D/S/P/H/N/A.")
        self.log("For the full sequence, use command A - ALL main tests.")

    def _command_combo_changed(self, event=None):
        value = event.widget.get()
        if value:
            self.command.set(value.split(" ", 1)[0])

    def log(self, msg):
        self.log_queue.put(str(msg))

    def _drain_log_queue(self):
        try:
            while True:
                msg = self.log_queue.get_nowait()
                self.log_text.insert(tk.END, msg + "\n")
                self.log_text.see(tk.END)
        except queue.Empty:
            pass
        self.after(100, self._drain_log_queue)

    def selected_sketch(self):
        ms = self.microstep.get()
        sketch_name = f"SDC2_TestRunner_Menu_{ms}u"
        sketch_dir = ROOT / sketch_name
        return sketch_name, sketch_dir

    def run_command(self, cmd, cwd=None, after=None):
        if self.process is not None and self.process.poll() is None:
            messagebox.showwarning("Process running", "A process is already running. Stop it first or wait for it to finish.")
            return
        self.worker_thread = threading.Thread(target=self._run_command_worker, args=(cmd, cwd or ROOT, after), daemon=True)
        self.worker_thread.start()

    def _run_command_worker(self, cmd, cwd, after):
        self.log("")
        self.log("> " + " ".join(str(x) for x in cmd))
        self.log(f"cwd: {cwd}")
        try:
            self.process = subprocess.Popen(
                cmd,
                cwd=str(cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                text=True,
                bufsize=1,
                shell=False,
            )
            assert self.process.stdout is not None
            for line in self.process.stdout:
                self.log(line.rstrip())
            rc = self.process.wait()
            self.log(f"Process finished with exit code {rc}")
            self.process = None
            if rc == 0 and after:
                after()
        except Exception as e:
            self.process = None
            self.log(f"ERROR: {e}")

    def compile_firmware(self):
        _, sketch_dir = self.selected_sketch()
        if not sketch_dir.exists():
            messagebox.showerror("Missing sketch", f"Sketch folder not found:\n{sketch_dir}")
            return
        self.run_command(["arduino-cli", "compile", "--fqbn", self.fqbn.get(), str(sketch_dir)])

    def upload_firmware(self):
        _, sketch_dir = self.selected_sketch()
        if not sketch_dir.exists():
            messagebox.showerror("Missing sketch", f"Sketch folder not found:\n{sketch_dir}")
            return
        self.run_command(["arduino-cli", "upload", "-p", self.port.get(), "--fqbn", self.fqbn.get(), str(sketch_dir)])

    def compile_upload_firmware(self):
        _, sketch_dir = self.selected_sketch()
        if not sketch_dir.exists():
            messagebox.showerror("Missing sketch", f"Sketch folder not found:\n{sketch_dir}")
            return
        def upload_after():
            self.run_command(["arduino-cli", "upload", "-p", self.port.get(), "--fqbn", self.fqbn.get(), str(sketch_dir)])
        self.run_command(["arduino-cli", "compile", "--fqbn", self.fqbn.get(), str(sketch_dir)], after=upload_after)

    def compile_upload_run(self):
        _, sketch_dir = self.selected_sketch()
        def run_after_upload():
            self.after(1500, self.run_selected_test)
        def upload_after_compile():
            self.run_command(["arduino-cli", "upload", "-p", self.port.get(), "--fqbn", self.fqbn.get(), str(sketch_dir)], after=run_after_upload)
        self.run_command(["arduino-cli", "compile", "--fqbn", self.fqbn.get(), str(sketch_dir)], after=upload_after_compile)

    def make_run_paths(self, command):
        ms = self.microstep.get()
        stamp = now_stamp()
        run_dir = ROOT / "SDC2_GUI_results" / f"{ms}u" / f"{command}_{stamp}"
        run_dir.mkdir(parents=True, exist_ok=True)
        raw_csv = run_dir / f"SDC2_{ms}u_{command}_{stamp}.csv"
        self.last_run_dir.set(str(run_dir))
        self.last_csv.set(str(raw_csv))
        return run_dir, raw_csv

    def run_selected_test(self):
        cmd_value = self.command.get()
        if " " in cmd_value:
            cmd_value = cmd_value.split(" ",1)[0]
        if cmd_value not in COMMANDS:
            messagebox.showerror("Invalid command", "Pick one of D/S/P/H/N/A.")
            return
        run_dir, raw_csv = self.make_run_paths(cmd_value)
        max_seconds = self.max_seconds.get().strip() or "0"
        args = [PY, str(ROOT / "python" / "sdc2_serial_logger.py"),
                "--port", self.port.get(),
                "--baud", self.baud.get(),
                "--command", cmd_value,
                "--output", str(raw_csv),
                "--max-seconds", max_seconds]
        def after_logger():
            self.log(f"Logger finished. Raw CSV: {raw_csv}")
            if not self._valid_csv_for_analysis(raw_csv):
                self.log("Skipping postprocess/Allan analysis because the CSV is not valid.")
                return
            if self.auto_postprocess.get():
                self._run_postprocess(raw_csv, run_dir)
            elif self.auto_allan.get():
                self._run_allan(raw_csv, run_dir)
        self.run_command(args, after=after_logger)

    def _run_postprocess(self, raw_csv, run_dir):
        out = Path(run_dir) / "event_postprocess"
        args = [PY, str(ROOT / "python" / "sdc2_postprocess_fullchar.py"),
                "--input", str(raw_csv),
                "--out", str(out),
                "--microstep", self.microstep.get()]
        def after_post():
            self.log(f"Postprocess finished. Output: {out}")
            if self.auto_allan.get():
                self._run_allan(raw_csv, run_dir)
        self.run_command(args, after=after_post)

    def _run_allan(self, raw_csv, run_dir):
        out = Path(run_dir) / "allan_analysis"
        args = [PY, str(ROOT / "python" / "sdc2_allan_analysis.py"),
                "--input", str(raw_csv),
                "--out", str(out),
                "--microstep", self.microstep.get()]
        self.run_command(args, after=lambda: self.log(f"Allan analysis finished. Output: {out}"))


    def _valid_csv_for_analysis(self, raw_csv):
        raw_csv = Path(raw_csv)
        if not raw_csv.exists():
            self.log(f"ERROR: CSV does not exist: {raw_csv}")
            return False
        if raw_csv.stat().st_size == 0:
            self.log(f"ERROR: CSV is empty, skipping analysis: {raw_csv}")
            return False
        try:
            first = raw_csv.open("r", encoding="utf-8", errors="replace").readline().strip()
        except Exception as e:
            self.log(f"ERROR: could not read CSV header: {e}")
            return False
        if not (first.startswith("Time_s") or first.startswith("RunLabel,")):
            self.log(f"ERROR: CSV does not start with expected SDC2 header: {raw_csv}")
            self.log(f"First line: {first}")
            return False
        return True

    def analyze_existing_csv(self):
        csv_path = filedialog.askopenfilename(title="Select SDC2 CSV", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not csv_path:
            return
        run_dir = Path(csv_path).resolve().parent / "GUI_reanalysis"
        run_dir.mkdir(exist_ok=True)
        self.last_csv.set(csv_path)
        self.last_run_dir.set(str(run_dir))
        if self._valid_csv_for_analysis(Path(csv_path)):
            self._run_postprocess(Path(csv_path), run_dir)

    def allan_existing_csv(self):
        csv_path = filedialog.askopenfilename(title="Select SDC2 CSV", filetypes=[("CSV files", "*.csv"), ("All files", "*.*")])
        if not csv_path:
            return
        run_dir = Path(csv_path).resolve().parent / "GUI_allan_reanalysis"
        run_dir.mkdir(exist_ok=True)
        self.last_csv.set(csv_path)
        self.last_run_dir.set(str(run_dir))
        if self._valid_csv_for_analysis(Path(csv_path)):
            self._run_allan(Path(csv_path), run_dir)

    def open_last_run_folder(self):
        path = self.last_run_dir.get().strip()
        if not path:
            messagebox.showinfo("No folder", "No run folder yet.")
            return
        self._open_folder(Path(path))

    def open_root_folder(self):
        self._open_folder(ROOT)

    def _open_folder(self, path: Path):
        if not path.exists():
            messagebox.showerror("Missing folder", str(path))
            return
        if os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])

    def stop_process(self):
        if self.process is None or self.process.poll() is not None:
            self.log("No active subprocess to stop.")
            return
        if messagebox.askyesno("Stop process", "Kill the running subprocess? If the motor is moving, use hardware stop/reset too."):
            try:
                self.process.terminate()
                self.log("Sent terminate to subprocess.")
            except Exception as e:
                self.log(f"Terminate failed: {e}")


if __name__ == "__main__":
    app = SDC2UI()
    app.mainloop()
