@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

echo.
echo ========================================
echo SDC2 16 USTEP - UPLOAD AND RUN MENU
echo ========================================
echo.

REM ============================================================
REM USER SETTINGS
REM ============================================================

set PORT=COM5
set FQBN=arduino:mbed_giga:giga
set BAUD=115200

set SKETCH_NAME=SDC2_TestRunner_Menu
set SKETCH_DIR=%~dp0%SKETCH_NAME%
set SKETCH_FILE=%SKETCH_DIR%\%SKETCH_NAME%.ino

set LOGGER=sdc2_serial_logger.py
set POST=sdc2_postprocess_fullchar.py
set OUTDIR=SDC2_results_16u
set RUNS_DIR=runs

REM ============================================================
REM CHECK FILES / SKETCH FOLDER
REM ============================================================

if not exist "%SKETCH_DIR%" (
    echo Sketch folder not found. Creating:
    echo %SKETCH_DIR%
    mkdir "%SKETCH_DIR%"
)

if not exist "%SKETCH_FILE%" (
    if exist "%~dp0%SKETCH_NAME%.ino" (
        echo Moving %SKETCH_NAME%.ino into sketch folder...
        move "%~dp0%SKETCH_NAME%.ino" "%SKETCH_FILE%"
    ) else (
        echo.
        echo ERROR: Could not find %SKETCH_NAME%.ino
        echo Expected either:
        echo   %~dp0%SKETCH_NAME%.ino
        echo or:
        echo   %SKETCH_FILE%
        echo.
        pause
        exit /b 1
    )
)

if not exist "%LOGGER%" (
    echo.
    echo ERROR: Could not find %LOGGER%
    echo Put this batch file in the same folder as %LOGGER%.
    echo.
    pause
    exit /b 1
)

if not exist "%POST%" (
    echo.
    echo ERROR: Could not find %POST%
    echo Put this batch file in the same folder as %POST%.
    echo.
    pause
    exit /b 1
)

if not exist "%RUNS_DIR%" mkdir "%RUNS_DIR%"
if not exist "%OUTDIR%" mkdir "%OUTDIR%"

REM ============================================================
REM DISPLAY SETTINGS
REM ============================================================

echo Using port:      %PORT%
echo Using board:     %FQBN%
echo Using baud:      %BAUD%
echo Sketch file:
echo   %SKETCH_FILE%
echo Runs folder:
echo   %RUNS_DIR%
echo Results folder:
echo   %OUTDIR%
echo.
echo HARDWARE CHECK:
echo   R725 must be set to 16 microsteps:
echo   SW1 = D, SW2 = D, SW3 = U, SW4 = U
echo.

REM ============================================================
REM COMPILE
REM ============================================================

echo Compiling sketch...
arduino-cli compile --fqbn %FQBN% "%SKETCH_DIR%"

if errorlevel 1 (
    echo.
    echo Compile failed.
    pause
    exit /b 1
)

REM ============================================================
REM UPLOAD
REM ============================================================

echo.
echo Uploading sketch to Arduino...
arduino-cli upload -p %PORT% --fqbn %FQBN% "%SKETCH_DIR%"

if errorlevel 1 (
    echo.
    echo Upload failed.
    echo Check that the Arduino is on %PORT%.
    pause
    exit /b 1
)

echo.
echo Upload complete.
echo Waiting for board reset...
timeout /t 5 /nobreak >nul

REM ============================================================
REM LOGGER MENU
REM ============================================================

:MENU
echo.
echo ========================================
echo SDC2 16 USTEP LOGGER MENU
echo ========================================
echo.
echo 1 = DEBUG        short constant-speed sanity test
echo 2 = HIGHSPEED    10, 20, 30, 40, 50 deg/s both directions
echo 3 = PROTOCOL     0.01, 0.03, 1, 3, 5, 10, 15 deg/s both directions
echo 4 = STATIC       static 50 Hz and 100 Hz hold tests
echo 5 = SINE         sine velocity tests, peak 15 deg/s
echo 6 = ALL          static + protocol + highspeed + sine
echo 7 = MENU ONLY    send ? to Arduino and log response briefly
echo 8 = Analyze existing CSV only
echo 9 = Open results folder
echo 0 = Exit
echo.

set /p CHOICE=Enter choice: 

if "%CHOICE%"=="1" goto RUN_DEBUG
if "%CHOICE%"=="2" goto RUN_HIGHSPEED
if "%CHOICE%"=="3" goto RUN_PROTOCOL
if "%CHOICE%"=="4" goto RUN_STATIC
if "%CHOICE%"=="5" goto RUN_SINE
if "%CHOICE%"=="6" goto RUN_ALL
if "%CHOICE%"=="7" goto RUN_INFO
if "%CHOICE%"=="8" goto ANALYZE_EXISTING
if "%CHOICE%"=="9" goto OPEN_RESULTS
if "%CHOICE%"=="0" goto DONE

echo.
echo Invalid choice.
goto MENU

:RUN_DEBUG
set CMD=D
set LABEL=debug
goto RUN_COMMAND

:RUN_HIGHSPEED
set CMD=H
set LABEL=highspeed_10_50
goto RUN_COMMAND

:RUN_PROTOCOL
set CMD=P
set LABEL=protocol_constants
goto RUN_COMMAND

:RUN_STATIC
set CMD=S
set LABEL=static
goto RUN_COMMAND

:RUN_SINE
set CMD=N
set LABEL=sine
goto RUN_COMMAND

:RUN_ALL
set CMD=A
set LABEL=all_tests
goto RUN_COMMAND

:RUN_INFO
set CMD=?
set LABEL=arduino_menu
goto RUN_COMMAND_SHORT

:RUN_COMMAND
echo.
echo Starting %LABEL% run with Arduino command %CMD%...
set CSV=%RUNS_DIR%\sdc2_16u_%LABEL%.csv
python "%LOGGER%" --port %PORT% --baud %BAUD% --command %CMD% --output "%CSV%"
if errorlevel 1 (
    echo.
    echo Logger failed or was interrupted.
    goto AFTER_RUN
)
echo.
echo Postprocessing %CSV%...
python "%POST%" --input "%CSV%" --out "%OUTDIR%\%LABEL%"
goto AFTER_RUN

:RUN_COMMAND_SHORT
echo.
echo Sending command %CMD% and logging briefly...
set CSV=%RUNS_DIR%\sdc2_16u_%LABEL%.csv
python "%LOGGER%" --port %PORT% --baud %BAUD% --command %CMD% --output "%CSV%" --max-seconds 8
if errorlevel 1 (
    echo.
    echo Logger failed or was interrupted.
)
goto AFTER_RUN

:ANALYZE_EXISTING
echo.
echo Enter CSV path to analyze.
echo Example:
echo   runs\sdc2_16u_highspeed_10_50.csv
echo.
set /p CSVPATH=CSV path: 

if not exist "%CSVPATH%" (
    echo.
    echo ERROR: CSV file not found:
    echo %CSVPATH%
    goto AFTER_RUN
)

echo.
echo Enter output subfolder name, or press Enter for existing_csv_analysis.
set /p SUBOUT=Output subfolder: 
if "%SUBOUT%"=="" set SUBOUT=existing_csv_analysis

echo.
echo Analyzing existing CSV...
python "%POST%" --input "%CSVPATH%" --out "%OUTDIR%\%SUBOUT%"
goto AFTER_RUN

:OPEN_RESULTS
echo.
if not exist "%OUTDIR%" (
    echo Results folder does not exist yet:
    echo %OUTDIR%
) else (
    explorer "%OUTDIR%"
)
goto MENU

:AFTER_RUN
echo.
echo ========================================
echo Run/analyze step finished.
echo ========================================
echo.
echo Runs are in:
echo   %CD%\%RUNS_DIR%
echo Results are in:
echo   %CD%\%OUTDIR%
echo.
echo Options:
echo   M = return to menu
echo   O = open results folder
echo   X = exit
echo.
set /p NEXT=Enter M, O, or X: 

if /I "%NEXT%"=="M" goto MENU
if /I "%NEXT%"=="O" (
    if exist "%OUTDIR%" explorer "%OUTDIR%"
    goto MENU
)
if /I "%NEXT%"=="X" goto DONE

goto MENU

:DONE
echo.
echo Done.
pause
endlocal
