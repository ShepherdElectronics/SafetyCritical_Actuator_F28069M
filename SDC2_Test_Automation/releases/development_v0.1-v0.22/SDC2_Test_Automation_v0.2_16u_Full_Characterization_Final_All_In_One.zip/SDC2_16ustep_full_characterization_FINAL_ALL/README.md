# SDC2 16-ustep full characterization package

This is the final all-in-one SDC2 test package for the Arduino GIGA + R725 + geared stepper + E5 encoder setup at **16 microsteps**.

## Hardware setting

Before running, set the R725 DIP switches to 16 microsteps:

```text
SW1 = D
SW2 = D
SW3 = U
SW4 = U
```

The firmware is set for:

```text
MICROSTEP_SETTING = 16
Gear ratio = 24.65:1
Encoder before gearbox
D10 = STEP
D13 = DIR
D2 = Encoder A
D3 = Encoder B
D4 = Encoder Z/index logged only
Baud = 115200
```

## One-click run

Double-click:

```text
upload_and_run_sdc2.bat
```

The batch file will:

```text
1. Compile the Arduino sketch with arduino-cli
2. Upload it to the Arduino GIGA on COM5
3. Open a menu for debug/protocol/high-speed/static/sine tests
4. Log raw CSV files into runs/
5. Postprocess completed CSVs into SDC2_results_16u/
```

Edit these lines near the top of the batch file if needed:

```bat
set PORT=COM5
set FQBN=arduino:mbed_giga:giga
set BAUD=115200
```

## Menu options

```text
1 = DEBUG        short constant-speed sanity test
2 = HIGHSPEED    10, 20, 30, 40, 50 deg/s both directions
3 = PROTOCOL     0.01, 0.03, 1, 3, 5, 10, 15 deg/s both directions
4 = STATIC       static 50 Hz and 100 Hz hold tests
5 = SINE         sine velocity tests, peak 15 deg/s
6 = ALL          static + protocol + highspeed + sine
7 = MENU ONLY    send ? to Arduino and log response briefly
8 = Analyze existing CSV only
9 = Open results folder
0 = Exit
```

Recommended first run:

```text
1 = DEBUG
```

If that looks safe, run:

```text
2 = HIGHSPEED
```

## Main outputs

Raw logs:

```text
runs/*.csv
runs/*_metadata.txt
```

Postprocessed outputs:

```text
SDC2_results_16u/<run_name>/cleaned_sdc2_16u.csv
SDC2_results_16u/<run_name>/SDC2_16u_segment_summary.csv
SDC2_results_16u/<run_name>/SDC2_16u_speed_ratio_summary.png
SDC2_results_16u/<run_name>/event_figures/*.png
```

The event plots use raw encoder count changes only. No filtering, smoothing, or grouped averaging is applied to the event-speed figures.

## Included folders

```text
SDC2_TestRunner_Menu/                 root sketch folder used by the batch file
arduino/SDC2_FullChar_16u/             original 16-ustep firmware copy
python/                                logger and postprocessor source copies
matlab/                                MATLAB analysis scripts
reference/                             prior 256-ustep report and comparison figures
docs/                                  quick-start, manifest, and test-plan docs
runs/                                  created when logging
SDC2_results_16u/                      created when postprocessing
```

## Notes

This package also includes the older debug environment files for reference:

```text
sdc2_logger_plotter.py
run_sdc2_menu_legacy.bat
plot_existing_sdc2_csv_legacy.bat
README_legacy_debug_environment.md
```

For this 16-ustep package, use `upload_and_run_sdc2.bat` first.
