# SDC2 Live Telemetry Console Notes

Start with:

```text
launch_sdc2_ui.bat
```

## Added telemetry-console features

The GUI includes three tabs:

```text
Live Log | Live Plots | Summary
```

### Live Log
Shows raw serial output from the Arduino/logger.

### Live Plots
Shows rolling live telemetry previews:

- Encoder/table position vs time
- Commanded speed and measured speed vs time

The rolling buffer is capped at the last 5,000 parsed rows so Tkinter/matplotlib do not lag during long runs.

### Summary
Shows live sanity-check values:

- Samples received
- Elapsed time
- Latest measured speed
- Mean measured speed
- RMS position error
- Warnings
- Latest state
- Latest fault

## Quick file buttons

The bottom toolbar includes:

- Open last CSV
- Open live log/meta
- Open plots folder
- Open last run folder
- Open root folder

## Robust logging behavior

The serial logger now handles these failure modes:

- Missing CSV header at startup: synthesizes the known 24-column SDC2 header when valid SDC2 data rows are detected.
- Empty CSV: refuses to postprocess and shows a clear error.
- Single-test completion markers: stops cleanly when a single test finishes, not only on ALL_TESTS_COMPLETE.
- Windows serial read failure: saves captured rows as a partial CSV and records the failure in metadata.

If a serial exception occurs during a run, reset/power-cycle the Arduino/driver before starting another run, because the firmware may continue executing after the Python logger loses the COM port.
