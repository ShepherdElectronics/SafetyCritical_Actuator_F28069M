# SDC2 Full Characterization Package - 16 ustep / 256 ustep + Allan Analysis

This package runs the SDC2 Arduino GIGA + R725 + E5 encoder characterization workflow with selectable firmware for either:

- **16 microsteps** for high-speed / full characterization attempts
- **256 microsteps** for the original ultra-slow smoothness baseline

The one-click entry point is:

```text
upload_and_run_sdc2.bat
```

## What the batch file does

1. Lets you choose **16 ustep** or **256 ustep** firmware.
2. Compiles and uploads the matching Arduino sketch with `arduino-cli`.
3. Opens the logger menu.
4. Runs the selected test and saves raw CSV data under `runs/`.
5. Runs event-based postprocessing.
6. Runs Allan deviation analysis and exports annotated figures.

## Microstep DIP settings

| Setting | R725 DIP switch setting | Use case |
|---:|---|---|
| 16 ustep | SW1=D, SW2=D, SW3=U, SW4=U | Faster characterization, 10-50 deg/s testing, lower pulse-rate burden |
| 256 ustep | SW1=D, SW2=D, SW3=D, SW4=U | Ultra-slow baseline and smoothness comparison |

Always physically set the R725 DIP switches to match the firmware before running a test.

## Logger menu

After upload, the batch menu shows:

```text
1 = DEBUG        short sanity test
2 = HIGHSPEED    10, 20, 30, 40, 50 deg/s both directions
3 = PROTOCOL     0.01, 0.03, 1, 3, 5, 10, 15 deg/s both directions
4 = STATIC       static 50 Hz and 100 Hz hold tests for Allan deviation
5 = SINE         sine velocity tests, peak 15 deg/s
6 = ALL          static + protocol + highspeed + sine
7 = MENU ONLY    send ? to Arduino and log response briefly
8 = Analyze existing CSV: event plots + Allan plots
9 = Open results folder
C = Change/upload microstep firmware
0 = Exit
```

For the entire firmware sequence, use:

```text
6 = ALL
```

For pure Allan-source static data, use:

```text
4 = STATIC
```

## Output structure

For each run, outputs are saved like this:

```text
runs/
  sdc2_16u_static_allan_source.csv
  sdc2_256u_protocol_constants.csv

SDC2_results_16u/<run_label>/
  event_analysis/
    SDC2_clean.csv
    SDC2_16u_full_characterization_summary.csv
    SDC2_16u_combined_summary.png
    per-segment event figures
  allan_analysis/
    SDC2_Allan_summary.csv
    SDC2_Allan_combined_minimum_summary.png
    allan_csv/
      per-signal Allan CSVs
    allan_figures/
      annotated Allan deviation figures
      time-series figures used for Allan input

SDC2_results_256u/<run_label>/
  same structure as above
```

## Allan analysis details

The Allan script computes overlapping Allan deviation for each segment and signal where available:

- relative table position
- position residual after best-fit line removal
- position error
- measured speed
- speed error

Figures include:

- log-log Allan deviation plot
- minor grids
- slope guides: -0.5, 0, +0.5, +1
- annotations for segment, microstep setting, minimum Allan deviation, tau at minimum, and estimator method
- companion time-series figure showing the raw signal used as Allan input

## Important method distinction

Event-speed figures use raw encoder count-change timing and state explicitly:

```text
raw encoder counts; no filtering/smoothing/group averaging
```

Allan deviation is different: it is intentionally an averaging-time statistic. The Allan script does not pre-smooth the input signal, but Allan deviation itself evaluates how signal variation changes as averaging time `tau` changes.

## Files of interest

```text
upload_and_run_sdc2.bat                      main one-click runner
sdc2_serial_logger.py                        serial CSV logger
sdc2_postprocess_fullchar.py                 event-based plots and summaries
sdc2_allan_analysis.py                       Allan deviation analysis and figures
SDC2_TestRunner_Menu_16u/                    Arduino sketch for 16 ustep
SDC2_TestRunner_Menu_256u/                   Arduino sketch for 256 ustep
reference/allan/                             Allan deviation reference PDFs
reference/SDC2_256ustep_TI_Style_Report...  prior 256 ustep review PDF
```

## GUI launcher

A simple Tkinter UI is included:

```text
launch_sdc2_ui.bat
```

The UI can:

```text
select 16 or 256 microstep firmware
compile/upload with arduino-cli
run D/S/P/H/N/A commands
save raw CSVs under SDC2_GUI_results
run event-based postprocessing
run Allan deviation analysis
open the output folder
```

Recommended order:

```text
1. Set physical R725 DIP switches to match 16 or 256 microstep selection.
2. Open launch_sdc2_ui.bat.
3. Select microstep firmware.
4. Click Compile + upload.
5. Run D first, then S/P/H/N, then A only after the smaller tests behave.
```
