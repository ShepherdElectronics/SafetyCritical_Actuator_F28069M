#!/usr/bin/env python3
"""
SDC2 serial logger for Arduino firmware.

Example:
  python sdc2_serial_logger.py --port COM3 --command H --output runs/sdc2_16u_highspeed_10_50.csv

Commands are passed to the Arduino after the port opens:
  D debug
  S static tests
  P official protocol constants
  H high-speed 10-50 deg/s
  N sine tests
  A all final tests
"""

import argparse
import csv
import os
import sys
import time
from datetime import datetime

try:
    import serial
except ImportError:
    print("ERROR: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
    raise


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--port", required=True, help="Serial port, e.g. COM3")
    p.add_argument("--baud", type=int, default=115200)
    p.add_argument("--command", default="?", help="Arduino command to send: D,S,P,H,N,A,Z,?")
    p.add_argument("--output", default="", help="Output CSV path. Default uses timestamp in runs/.")
    p.add_argument("--timeout", type=float, default=2.0)
    p.add_argument("--max-seconds", type=float, default=0.0, help="Optional forced stop/logging duration. 0 = until Ctrl+C.")
    return p.parse_args()


def main():
    args = parse_args()

    if not args.output:
        os.makedirs("runs", exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        args.output = os.path.join("runs", f"sdc2_16u_{args.command}_{stamp}.csv")
    else:
        outdir = os.path.dirname(args.output)
        if outdir:
            os.makedirs(outdir, exist_ok=True)

    print(f"Opening {args.port} at {args.baud} baud")
    ser = serial.Serial(args.port, args.baud, timeout=args.timeout)
    time.sleep(2.5)
    ser.reset_input_buffer()

    print(f"Sending command: {args.command}")
    ser.write((args.command + "\n").encode("ascii"))
    ser.flush()

    start = time.time()
    csv_started = False
    header = None
    rows = 0
    comments = []

    with open(args.output, "w", newline="", encoding="utf-8") as f:
        writer = None
        try:
            while True:
                if args.max_seconds > 0 and (time.time() - start) > args.max_seconds:
                    print("Max seconds reached. Sending stop command X.")
                    ser.write(b"X\n")
                    ser.flush()
                    break

                raw = ser.readline()
                if not raw:
                    continue
                line = raw.decode("utf-8", errors="replace").strip()
                if not line:
                    continue

                print(line)

                if line.startswith("#"):
                    comments.append(line)
                    continue

                parts = [x.strip() for x in line.split(",")]

                # Header row starts with Time_s
                if parts and parts[0] == "Time_s":
                    header = parts
                    writer = csv.writer(f)
                    writer.writerow(header)
                    csv_started = True
                    continue

                if csv_started and writer is not None:
                    # Skip malformed short lines, but keep logging.
                    if len(parts) == len(header):
                        writer.writerow(parts)
                        rows += 1
                    else:
                        comments.append("# MALFORMED," + line)

        except KeyboardInterrupt:
            print("\nCtrl+C received. Sending stop command X.")
            try:
                ser.write(b"X\n")
                ser.flush()
            except Exception:
                pass
        finally:
            ser.close()

    meta_path = args.output.replace(".csv", "_metadata.txt")
    with open(meta_path, "w", encoding="utf-8") as mf:
        mf.write(f"port={args.port}\n")
        mf.write(f"baud={args.baud}\n")
        mf.write(f"command={args.command}\n")
        mf.write(f"output={args.output}\n")
        mf.write(f"rows={rows}\n")
        mf.write("\n# Serial comments\n")
        for c in comments:
            mf.write(c + "\n")

    print(f"Saved CSV: {args.output}")
    print(f"Rows: {rows}")
    print(f"Saved metadata: {meta_path}")


if __name__ == "__main__":
    main()
