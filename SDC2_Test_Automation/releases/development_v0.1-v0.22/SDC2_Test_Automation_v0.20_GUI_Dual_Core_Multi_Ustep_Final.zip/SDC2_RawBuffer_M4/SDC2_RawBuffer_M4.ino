/*
  SDC2_RawBuffer_M4.ino

  Arduino GIGA / STM32H747 dual-core companion sketch.

  Purpose:
    M4-side buffered data-acquisition/logging worker scaffold.

  Intended architecture:
    M7 core = deterministic real-time motion/control target.
    M4 core = high-rate raw sample buffering, drop counting, and later post-segment dump support.
    PC host = GUI, live preview, CSV/raw-dump storage, offline analysis.

  Notes:
    - This is a scaffold for the GIGA dual-core phase. It exposes an RPC surface for status/clear/push.
    - For the final high-rate implementation, prefer shared-memory or a lock-free dual-core buffer over per-sample RPC if RPC overhead is too high.
    - Upload this sketch to the M4 core, then upload the M7 target sketch.
*/

#include <Arduino.h>
#include <RPC.h>

struct RawSample {
  uint32_t t_us;
  int32_t encoder_count;
  int32_t position_mdeg;
  int32_t target_mdeg_s;
  int32_t profile_mdeg_s;
  int32_t measured_mdeg_s;
  uint16_t state_id;
  uint16_t flags;
};

static const uint32_t RAW_CAPACITY = 8192;  // conservative scaffold; expand after SRAM/shared-memory validation
static RawSample rawBuf[RAW_CAPACITY];
static volatile uint32_t rawWrite = 0;
static volatile uint32_t rawCount = 0;
static volatile uint32_t rawDrops = 0;
static volatile uint32_t rawSession = 0;

int rawClear() {
  noInterrupts();
  rawWrite = 0;
  rawCount = 0;
  rawDrops = 0;
  rawSession++;
  interrupts();
  return (int)rawSession;
}

int rawStatus() {
  // compact status: lower 16 bits count, upper 16 bits drops clipped
  uint32_t c = rawCount;
  uint32_t d = rawDrops;
  if (c > 65535) c = 65535;
  if (d > 65535) d = 65535;
  return (int)((d << 16) | c);
}

int rawCountRpc() {
  return (int)rawCount;
}

int rawDropsRpc() {
  return (int)rawDrops;
}

int rawPush(uint32_t t_us,
            int32_t encoder_count,
            int32_t position_mdeg,
            int32_t target_mdeg_s,
            int32_t profile_mdeg_s,
            int32_t measured_mdeg_s,
            uint32_t state_flags) {
  uint16_t state_id = (uint16_t)(state_flags & 0xFFFFu);
  uint16_t flags = (uint16_t)((state_flags >> 16) & 0xFFFFu);

  noInterrupts();
  if (rawCount >= RAW_CAPACITY) {
    rawDrops++;
    interrupts();
    return 0;
  }
  uint32_t idx = rawWrite;
  rawBuf[idx].t_us = t_us;
  rawBuf[idx].encoder_count = encoder_count;
  rawBuf[idx].position_mdeg = position_mdeg;
  rawBuf[idx].target_mdeg_s = target_mdeg_s;
  rawBuf[idx].profile_mdeg_s = profile_mdeg_s;
  rawBuf[idx].measured_mdeg_s = measured_mdeg_s;
  rawBuf[idx].state_id = state_id;
  rawBuf[idx].flags = flags;
  rawWrite = (rawWrite + 1) % RAW_CAPACITY;
  rawCount++;
  interrupts();
  return 1;
}

void setup() {
  RPC.begin();
  RPC.bind("rawClear", rawClear);
  RPC.bind("rawStatus", rawStatus);
  RPC.bind("rawCount", rawCountRpc);
  RPC.bind("rawDrops", rawDropsRpc);
  RPC.bind("rawPush", rawPush);
}

void loop() {
  // M4 worker intentionally stays light. Future work: shared-memory dump, compression, checksums.
  delay(10);
}
